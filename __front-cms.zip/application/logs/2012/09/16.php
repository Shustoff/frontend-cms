<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-09-16 23:08:43 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:08:43 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:09:59 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:09:59 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:10:35 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:10:35 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:11:15 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:11:15 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:13:45 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:13:45 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:13:55 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:13:55 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:14:01 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:14:01 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:14:03 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:14:03 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:14:05 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:14:05 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:14:08 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:14:08 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:14:16 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:14:16 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:18:03 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:18:03 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:20:07 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:20:07 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:21:01 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:21:01 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:26:14 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:26:14 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:26:20 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:26:20 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:26:28 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:26:28 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:27:16 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:27:16 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:27:18 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:27:18 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:27:21 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:27:21 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:27:27 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:27:27 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:28:58 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:28:58 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:30:10 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:30:10 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:30:25 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:30:25 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:31:13 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:31:13 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:31:23 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:31:23 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:31:55 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:31:55 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:33:15 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:33:15 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:34:26 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:34:26 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:36:14 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:36:14 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:36:23 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:36:23 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:36:36 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:36:36 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:39:05 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-16 23:39:05 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-16 23:47:32 --- ERROR: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'shustoff_music'@'localhost' (using password: YES) ~ MODPATH/database/classes/kohana/database/mysql.php [ 67 ]
2012-09-16 23:47:32 --- STRACE: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'shustoff_music'@'localhost' (using password: YES) ~ MODPATH/database/classes/kohana/database/mysql.php [ 67 ]
--
#0 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/database/mysql.php(432): Kohana_Database_MySQL->connect()
#1 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/database.php(473): Kohana_Database_MySQL->escape('site')
#2 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/database/query/builder.php(116): Kohana_Database->quote('site')
#3 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/database/query/builder/select.php(370): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL), Array)
#4 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Select->compile(Object(Database_MySQL))
#5 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/config/database/reader.php(49): Kohana_Database_Query->execute(Object(Database_MySQL))
#6 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/config/database/writer.php(26): Kohana_Config_Database_Reader->load('site')
#7 /home/shustoff/music.shustoff.su/system/classes/kohana/config.php(124): Kohana_Config_Database_Writer->load('site')
#8 /home/shustoff/music.shustoff.su/application/classes/controller/site/home.php(7): Kohana_Config->load('site.status')
#9 [internal function]: Controller_Site_Home->before()
#10 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#11 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#14 {main}
2012-09-16 23:51:24 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/catalog.php [ 29 ]
2012-09-16 23:51:24 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}