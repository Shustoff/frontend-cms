<?php defined('SYSPATH') or die('No direct script access.');

class Model_Option extends ORM {

    protected $_table_name = 'config';

}
