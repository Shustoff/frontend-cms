<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-09-08 16:59:10 --- ERROR: ErrorException [ 8 ]: Undefined variable: page ~ APPPATH\classes\controller\site\page.php [ 47 ]
2012-09-08 16:59:10 --- STRACE: ErrorException [ 8 ]: Undefined variable: page ~ APPPATH\classes\controller\site\page.php [ 47 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(47): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 47, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:43:38 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:43:38 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:43:39 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:43:39 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:43:40 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:43:40 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:43:41 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:43:41 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:43:43 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:43:43 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:43:44 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:43:44 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:43:45 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:43:45 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:43:50 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:43:50 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:44:06 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:44:06 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:44:44 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:44:44 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:44:56 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:44:56 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:44:57 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:44:57 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:45:00 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:45:00 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:45:02 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:45:02 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:46:31 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:46:31 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 20:48:32 --- ERROR: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
2012-09-08 20:48:32 --- STRACE: ErrorException [ 8 ]: Undefined index: systemname ~ APPPATH\classes\controller\admin\modules.php [ 90 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(90): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 90, Array)
#1 [internal function]: Controller_Admin_Modules->action_checksysname()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-08 21:00:29 --- ERROR: ErrorException [ 2 ]: mail() [function.mail]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
2012-09-08 21:00:29 --- STRACE: ErrorException [ 2 ]: mail() [function.mail]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mail() [<a href...', 'C:\wamp\www\fro...', 50, Array)
#1 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', '=?utf-8?Q?=D0=B...', '<p>=D1=8B=D1=84...', 'Message-ID: <13...', '')
#2 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', '=?utf-8?Q?=D0=B...', '<p>=D1=8B=D1=84...', 'Message-ID: <13...', '')
#3 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\frontend\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\frontend\application\classes\controller\admin\email.php(59): Email::send('manager@example...', 'admin@example.r...', '????????????', '<p>??????????</...', true)
#6 [internal function]: Controller_Admin_Email->action_send()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-08 21:00:37 --- ERROR: ErrorException [ 2 ]: mail() [function.mail]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
2012-09-08 21:00:37 --- STRACE: ErrorException [ 2 ]: mail() [function.mail]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mail() [<a href...', 'C:\wamp\www\fro...', 50, Array)
#1 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', '=?utf-8?Q?=D0=B...', '<p>=D1=8B=D1=84...', 'Message-ID: <13...', '')
#2 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', '=?utf-8?Q?=D0=B...', '<p>=D1=8B=D1=84...', 'Message-ID: <13...', '')
#3 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\frontend\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\frontend\application\classes\controller\admin\email.php(59): Email::send('manager@example...', 'admin@example.r...', '????????????', '<p>??????????</...', true)
#6 [internal function]: Controller_Admin_Email->action_send()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-08 21:00:48 --- ERROR: ErrorException [ 2 ]: mail() [function.mail]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
2012-09-08 21:00:48 --- STRACE: ErrorException [ 2 ]: mail() [function.mail]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mail() [<a href...', 'C:\wamp\www\fro...', 50, Array)
#1 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('register@exampl...', '=?utf-8?Q?=D0=B...', '<p>=D1=8B=D1=84...', 'Message-ID: <13...', '')
#2 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('register@exampl...', '=?utf-8?Q?=D0=B...', '<p>=D1=8B=D1=84...', 'Message-ID: <13...', '')
#3 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\frontend\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\frontend\application\classes\controller\admin\email.php(59): Email::send('register@exampl...', 'admin@example.r...', '????????????', '<p>??????????</...', true)
#6 [internal function]: Controller_Admin_Email->action_send()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-08 21:26:30 --- ERROR: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-09-08 21:26:30 --- STRACE: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT username...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(27): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Admin_Stats->action_index()
#3 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#4 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-08 21:26:31 --- ERROR: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-09-08 21:26:31 --- STRACE: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT username...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(27): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Admin_Stats->action_index()
#3 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#4 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-08 21:26:38 --- ERROR: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-09-08 21:26:38 --- STRACE: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT username...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(27): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Admin_Stats->action_index()
#3 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#4 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-08 21:26:44 --- ERROR: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-09-08 21:26:44 --- STRACE: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT username...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(27): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Admin_Stats->action_index()
#3 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#4 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-08 21:27:22 --- ERROR: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-09-08 21:27:22 --- STRACE: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE max(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT username...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(27): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Admin_Stats->action_index()
#3 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#4 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-08 21:28:16 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
2012-09-08 21:28:16 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_stats.php(51): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 51, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(44): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Stats->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-08 21:30:23 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
2012-09-08 21:30:23 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_stats.php(51): Kohana_Core::error_handler(8, 'Undefined offse...', 'C:\wamp\www\fro...', 51, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(44): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Stats->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-08 21:30:24 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
2012-09-08 21:30:24 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_stats.php(51): Kohana_Core::error_handler(8, 'Undefined offse...', 'C:\wamp\www\fro...', 51, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(44): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Stats->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-08 21:30:33 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
2012-09-08 21:30:33 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_stats.php(51): Kohana_Core::error_handler(8, 'Undefined offse...', 'C:\wamp\www\fro...', 51, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(44): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Stats->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-08 21:33:40 --- ERROR: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE MAX(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-09-08 21:33:40 --- STRACE: Database_Exception [ 1111 ]: Invalid use of group function [ SELECT username FROM users WHERE MAX(logins) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT username...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(27): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Admin_Stats->action_index()
#3 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#4 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-08 21:37:32 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-09-08 21:37:32 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #127, 'username')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('username')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_stats.php(51): Kohana_Database_Result->offsetGet('username')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(44): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Stats->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-09-08 21:37:45 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
2012-09-08 21:37:45 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_stats.php(51): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 51, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(44): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Stats->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-08 21:37:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$username ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
2012-09-08 21:37:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$username ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_stats.php(51): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 51, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(44): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Stats->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-08 21:38:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
2012-09-08 21:38:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_stats.php [ 51 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_stats.php(51): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 51, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\stats.php(45): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Stats->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Stats))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}