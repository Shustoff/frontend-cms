<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-10-31 01:14:35 --- ERROR: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
2012-10-31 01:14:35 --- STRACE: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdf', '<p>wefw</p>??', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdf', '<p>wefw</p>??', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdf', '<p>wefw</p>?', true)
#6 [internal function]: Controller_Admin_Email->action_send()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#11 {main}
2012-10-31 01:15:33 --- ERROR: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
2012-10-31 01:15:33 --- STRACE: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'gffgfgf', '<p>wefw</p>??', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'gffgfgf', '<p>wefw</p>??', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'gffgfgf', '<p>wefw</p>?', true)
#6 [internal function]: Controller_Admin_Email->action_send()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#11 {main}
2012-10-31 11:43:33 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-10-31 11:43:33 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#5 {main}
2012-10-31 13:05:26 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-10-31 13:05:26 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#5 {main}
2012-10-31 14:20:59 --- ERROR: View_Exception [ 0 ]: The requested view /admin/index could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-10-31 14:20:59 --- STRACE: View_Exception [ 0 ]: The requested view /admin/index could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\view.php(137): Kohana_View->set_filename('/admin/index')
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\view.php(30): Kohana_View->__construct('/admin/index', NULL)
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller\template.php(33): Kohana_View::factory('/admin/index')
#3 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\main.php(14): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#9 {main}
2012-10-31 14:38:26 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-10-31 14:38:26 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#5 {main}
2012-10-31 18:54:52 --- ERROR: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
2012-10-31 18:54:52 --- STRACE: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
--
#0 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image\imagick.php(45): Kohana_Image_Imagick::check()
#1 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image.php(53): Kohana_Image_Imagick->__construct('assets/img/site...')
#2 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\pages.php(106): Kohana_Image::factory('assets/img/site...', 'Imagick')
#3 [internal function]: Controller_Admin_Pages->action_upload()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#8 {main}
2012-10-31 18:55:25 --- ERROR: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
2012-10-31 18:55:25 --- STRACE: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
--
#0 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image\imagick.php(45): Kohana_Image_Imagick::check()
#1 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image.php(53): Kohana_Image_Imagick->__construct('assets/img/site...')
#2 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\pages.php(106): Kohana_Image::factory('assets/img/site...', 'Imagick')
#3 [internal function]: Controller_Admin_Pages->action_upload()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#8 {main}
2012-10-31 18:58:11 --- ERROR: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
2012-10-31 18:58:11 --- STRACE: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
--
#0 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image\imagick.php(45): Kohana_Image_Imagick::check()
#1 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image.php(53): Kohana_Image_Imagick->__construct('assets/img/site...')
#2 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\pages.php(106): Kohana_Image::factory('assets/img/site...', 'Imagick')
#3 [internal function]: Controller_Admin_Pages->action_upload()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#8 {main}
2012-10-31 19:07:35 --- ERROR: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
2012-10-31 19:07:35 --- STRACE: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
--
#0 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image\imagick.php(45): Kohana_Image_Imagick::check()
#1 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image.php(53): Kohana_Image_Imagick->__construct('assets/img/site...')
#2 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\pages.php(106): Kohana_Image::factory('assets/img/site...', 'Imagick')
#3 [internal function]: Controller_Admin_Pages->action_upload()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#8 {main}
2012-10-31 19:24:10 --- ERROR: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
2012-10-31 19:24:10 --- STRACE: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
--
#0 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image\imagick.php(45): Kohana_Image_Imagick::check()
#1 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image.php(53): Kohana_Image_Imagick->__construct('assets/img/site...')
#2 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\pages.php(106): Kohana_Image::factory('assets/img/site...', 'Imagick')
#3 [internal function]: Controller_Admin_Pages->action_upload()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#8 {main}
2012-10-31 19:31:01 --- ERROR: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
2012-10-31 19:31:01 --- STRACE: Kohana_Exception [ 0 ]: Imagick is not installed, or the extension is not loaded ~ MODPATH\image\classes\kohana\image\imagick.php [ 28 ]
--
#0 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image\imagick.php(45): Kohana_Image_Imagick::check()
#1 C:\wamp\www\music.shustoff.su\modules\image\classes\kohana\image.php(53): Kohana_Image_Imagick->__construct('assets/img/site...')
#2 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\pages.php(106): Kohana_Image::factory('assets/img/site...', 'Imagick')
#3 [internal function]: Controller_Admin_Pages->action_upload()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#8 {main}
2012-10-31 20:45:50 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\controller\admin\users.php [ 79 ]
2012-10-31 20:45:50 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\controller\admin\users.php [ 79 ]
--
#0 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\users.php(79): Kohana_Core::error_handler(8, 'Array to string...', 'C:\wamp\www\mus...', 79, Array)
#1 [internal function]: Controller_Admin_Users->action_add()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#6 {main}
2012-10-31 20:45:53 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\controller\admin\users.php [ 79 ]
2012-10-31 20:45:53 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\controller\admin\users.php [ 79 ]
--
#0 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\users.php(79): Kohana_Core::error_handler(8, 'Array to string...', 'C:\wamp\www\mus...', 79, Array)
#1 [internal function]: Controller_Admin_Users->action_add()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#6 {main}
2012-10-31 20:45:56 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\controller\admin\users.php [ 79 ]
2012-10-31 20:45:56 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\controller\admin\users.php [ 79 ]
--
#0 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\users.php(79): Kohana_Core::error_handler(8, 'Array to string...', 'C:\wamp\www\mus...', 79, Array)
#1 [internal function]: Controller_Admin_Users->action_add()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#6 {main}
2012-10-31 20:47:42 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\controller\admin\users.php [ 79 ]
2012-10-31 20:47:42 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\controller\admin\users.php [ 79 ]
--
#0 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\users.php(79): Kohana_Core::error_handler(8, 'Array to string...', 'C:\wamp\www\mus...', 79, Array)
#1 [internal function]: Controller_Admin_Users->action_add()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#6 {main}
2012-10-31 20:47:44 --- ERROR: ErrorException [ 8 ]: Undefined index: email ~ APPPATH\classes\controller\admin\users.php [ 59 ]
2012-10-31 20:47:44 --- STRACE: ErrorException [ 8 ]: Undefined index: email ~ APPPATH\classes\controller\admin\users.php [ 59 ]
--
#0 C:\wamp\www\music.shustoff.su\application\classes\controller\admin\users.php(59): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 59, Array)
#1 [internal function]: Controller_Admin_Users->action_add()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#6 {main}
2012-10-31 22:32:39 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-10-31 22:32:39 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#5 {main}