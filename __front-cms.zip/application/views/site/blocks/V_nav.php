<!-- Меню -->
<nav class="topmenu row">
    <ul>
        <li><a href="hardcore/">UK Hardcore</a></li>
        <li><a href="trance/">Trance</a></li>
        <li><a href="techno/">Techno | DnB</a></li>
        <li><a href="ambient/">Ambient | Psy</a></li>
        <li><a href="electro/">Electro</a></li>
        <div class="clear"></div>
    </ul>
</nav>
