<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-05-25 11:37:34 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:37:34 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:37:36 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:37:36 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:37:47 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:37:47 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:37:47 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:37:47 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:39:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/V_options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-25 11:39:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/V_options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 11:43:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/V_options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-25 11:43:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/V_options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 11:46:30 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:46:30 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:52:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:52:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:52:31 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:52:31 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:53:23 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:53:23 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:53:26 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:53:26 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:54:36 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:54:36 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:54:41 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:54:41 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:54:46 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:54:46 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 11:54:48 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 11:54:48 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:01:49 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 12:01:49 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:02:15 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 12:02:15 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:02:19 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 12:02:19 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:02:24 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 12:02:24 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:02:26 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
2012-05-25 12:02:26 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH\views\admin\index.php [ 72 ]
--
#0 C:\wamp\www\front-end\application\views\admin\index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 72, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\front-end\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:18:01 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_PUBLIC ~ APPPATH\classes\controller\admin\main.php [ 24 ]
2012-05-25 12:18:01 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_PUBLIC ~ APPPATH\classes\controller\admin\main.php [ 24 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-05-25 12:19:48 --- ERROR: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-05-25 12:19:48 --- STRACE: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\view.php(137): Kohana_View->set_filename('')
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(30): Kohana_View->__construct('', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(33): Kohana_View::factory('')
#3 C:\wamp\www\front-end\application\classes\controller\admin\main.php(7): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:19:54 --- ERROR: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-05-25 12:19:54 --- STRACE: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\view.php(137): Kohana_View->set_filename('')
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(30): Kohana_View->__construct('', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(33): Kohana_View::factory('')
#3 C:\wamp\www\front-end\application\classes\controller\admin\main.php(7): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:20:33 --- ERROR: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-05-25 12:20:33 --- STRACE: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\view.php(137): Kohana_View->set_filename('')
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(30): Kohana_View->__construct('', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(33): Kohana_View::factory('')
#3 C:\wamp\www\front-end\application\classes\controller\admin\main.php(7): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:20:37 --- ERROR: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-05-25 12:20:37 --- STRACE: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\view.php(137): Kohana_View->set_filename('')
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(30): Kohana_View->__construct('', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(33): Kohana_View::factory('')
#3 C:\wamp\www\front-end\application\classes\controller\admin\main.php(7): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:21:03 --- ERROR: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-05-25 12:21:03 --- STRACE: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\view.php(137): Kohana_View->set_filename('')
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(30): Kohana_View->__construct('', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(33): Kohana_View::factory('')
#3 C:\wamp\www\front-end\application\classes\controller\admin\main.php(7): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:21:20 --- ERROR: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-05-25 12:21:20 --- STRACE: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\view.php(137): Kohana_View->set_filename('')
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(30): Kohana_View->__construct('', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(33): Kohana_View::factory('')
#3 C:\wamp\www\front-end\application\classes\controller\admin\main.php(7): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:21:22 --- ERROR: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-05-25 12:21:22 --- STRACE: View_Exception [ 0 ]: The requested view  could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\view.php(137): Kohana_View->set_filename('')
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(30): Kohana_View->__construct('', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(33): Kohana_View::factory('')
#3 C:\wamp\www\front-end\application\classes\controller\admin\main.php(7): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 12:28:57 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\admin\main.php [ 12 ]
2012-05-25 12:28:57 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\admin\main.php [ 12 ]
--
#0 C:\wamp\www\front-end\application\classes\controller\admin\main.php(12): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 12, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 12:29:02 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\admin\main.php [ 12 ]
2012-05-25 12:29:02 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\admin\main.php [ 12 ]
--
#0 C:\wamp\www\front-end\application\classes\controller\admin\main.php(12): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 12, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 12:29:08 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\admin\main.php [ 12 ]
2012-05-25 12:29:08 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\admin\main.php [ 12 ]
--
#0 C:\wamp\www\front-end\application\classes\controller\admin\main.php(12): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 12, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 12:29:54 --- ERROR: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH\classes\controller\admin\main.php [ 13 ]
2012-05-25 12:29:54 --- STRACE: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH\classes\controller\admin\main.php [ 13 ]
--
#0 C:\wamp\www\front-end\application\classes\controller\admin\main.php(13): Kohana_Core::error_handler(2, 'Attempt to assi...', 'C:\wamp\www\fro...', 13, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 12:30:11 --- ERROR: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH\classes\controller\admin\main.php [ 14 ]
2012-05-25 12:30:11 --- STRACE: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH\classes\controller\admin\main.php [ 14 ]
--
#0 C:\wamp\www\front-end\application\classes\controller\admin\main.php(14): Kohana_Core::error_handler(2, 'Attempt to assi...', 'C:\wamp\www\fro...', 14, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 12:30:16 --- ERROR: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH\classes\controller\admin\main.php [ 13 ]
2012-05-25 12:30:16 --- STRACE: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH\classes\controller\admin\main.php [ 13 ]
--
#0 C:\wamp\www\front-end\application\classes\controller\admin\main.php(13): Kohana_Core::error_handler(2, 'Attempt to assi...', 'C:\wamp\www\fro...', 13, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:05:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-25 14:05:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-25 14:05:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-25 14:05:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-25 14:18:50 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 12 ]
2012-05-25 14:18:50 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 12 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(12): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 12, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:19:47 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 12 ]
2012-05-25 14:19:47 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 12 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(12): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 12, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:12 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:12 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:12 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:12 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:12 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:12 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:15 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:15 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:15 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:15 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:15 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:15 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:15 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:15 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:43 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:43 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:44 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:44 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:20:54 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:20:54 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:21:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:40 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:40 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:21:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:21:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:22:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:22:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:22:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:22:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:22:15 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:15 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:22:15 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:15 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:22:16 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:16 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:22:16 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:16 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:22:16 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:16 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:22:16 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:16 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:22:28 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:28 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:22:28 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:28 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:22:29 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:29 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:22:42 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 14:22:42 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 14:27:25 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
2012-05-25 14:27:25 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 72, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 14:27:26 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
2012-05-25 14:27:26 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 72, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 14:27:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
2012-05-25 14:27:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 72, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 14:27:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
2012-05-25 14:27:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 72, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 14:27:28 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
2012-05-25 14:27:28 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 72, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 14:27:29 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
2012-05-25 14:27:29 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 72 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 72, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 14:29:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:29:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:29:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:29:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:29:07 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:29:07 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:29:07 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:29:07 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:29:13 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:29:13 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:30:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:30:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:30:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:30:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:30:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:30:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:30:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:30:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:31:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages/pages was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:31:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages/pages was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:32:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:32:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:32:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:32:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:32:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:32:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:33:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:33:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:35:19 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:35:19 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:38:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:38:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:38:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:38:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:40:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:40:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:40:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:40:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:40:25 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:40:25 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:40:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:40:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:46:01 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 14:46:01 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:46:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/addpage was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:46:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/addpage was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:47:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:47:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:48:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:48:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:48:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:48:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:48:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:48:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:48:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:48:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 14:49:20 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 14:49:20 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogs/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:15:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:15:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:16:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:16:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:16:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:16:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:16:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:16:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:17:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:17:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:17:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:17:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:18:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/info was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:18:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/info was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:18:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:18:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:19:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:19:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/sendemail was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:20:19 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/trash was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:20:19 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/trash was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:20:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/addrss was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 15:20:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/addrss was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:21:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: admin/main/users/adduser ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-25 15:21:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: admin/main/users/adduser ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-25 15:21:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: admin/main/users/adduser ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-25 15:21:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: admin/main/users/adduser ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-25 15:21:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: admin/main/users/adduser ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-25 15:21:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: admin/main/users/adduser ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-25 15:23:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogssad/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 15:23:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/catalogssad/addcatalog was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 15:35:00 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:00 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:02 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:02 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:03 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:03 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:04 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:04 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:19 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:19 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:22 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:22 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:23 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:23 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:47 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:47 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:48 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:48 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:49 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:49 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:49 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:49 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:53 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:53 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:54 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:54 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:35:54 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:35:54 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:36:01 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:36:01 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:36:02 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:36:02 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:36:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:36:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:36:41 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:36:41 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:36:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:36:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:36:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:36:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:37:10 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:37:10 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:37:11 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:37:11 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:37:19 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:37:19 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:37:48 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:37:48 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:37:49 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:37:49 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:37:49 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:37:49 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:15 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:15 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:24 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:24 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:25 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:25 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:41 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:41 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:43 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:43 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:43 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:43 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:43 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:43 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:44 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:44 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:44 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:44 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:44 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:44 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:44 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:44 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:44 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:44 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:45 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:45 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:45 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:45 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:45 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:45 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:41:45 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:41:45 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:42:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:42:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:42:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:42:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:42:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:42:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:42:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:42:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:42:22 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:42:22 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:42:22 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:42:22 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:42:22 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:42:22 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:42:22 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:42:22 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:43:10 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:43:10 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:43:11 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:43:11 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 15:43:16 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 15:43:16 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 16:10:00 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 16:10:00 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 16:10:01 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 16:10:01 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 16:16:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/addpage was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 16:16:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/addpage was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 16:23:15 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 16:23:15 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 16:24:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/email was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 16:24:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/email was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 16:26:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/email was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 16:26:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/email was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 16:29:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/stats was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-05-25 16:29:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/main/stats was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 16:31:36 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/users.php [ 12 ]
2012-05-25 16:31:36 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/users.php [ 12 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/users.php(12): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 12, Array)
#1 [internal function]: Controller_Admin_Users->action_adduser()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 16:35:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/info was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 16:35:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/info was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 16:38:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 16:38:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 16:42:24 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '=' ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 16:42:24 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '=' ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-05-25 16:42:25 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '=' ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 16:42:25 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '=' ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-05-25 16:43:18 --- ERROR: View_Exception [ 0 ]: The requested view index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-05-25 16:43:18 --- STRACE: View_Exception [ 0 ]: The requested view index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(137): Kohana_View->set_filename('index')
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(30): Kohana_View->__construct('index', NULL)
#2 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_View::factory('index')
#3 [internal function]: Controller_Admin_Main->action_index()
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#8 {main}
2012-05-25 16:47:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-25 16:47:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-25 16:47:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-25 16:47:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-25 16:47:18 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
2012-05-25 16:47:18 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/admin/main.php [ 7 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/main.php(7): Kohana_Core::error_handler(2048, 'Creating defaul...', '/Applications/M...', 7, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-25 16:52:33 --- ERROR: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-05-25 16:52:33 --- STRACE: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin/blocks/V_...')
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(30): Kohana_View->__construct('admin/blocks/V_...', NULL)
#2 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/index.php(7): Kohana_View::factory('admin/blocks/V_...')
#3 [internal function]: Controller_Admin_Index->action_index()
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#8 {main}
2012-05-25 16:53:06 --- ERROR: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-05-25 16:53:06 --- STRACE: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin/blocks/V_...')
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(30): Kohana_View->__construct('admin/blocks/V_...', NULL)
#2 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/index.php(7): Kohana_View::factory('admin/blocks/V_...')
#3 [internal function]: Controller_Admin_Index->action_index()
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#8 {main}
2012-05-25 16:53:09 --- ERROR: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-05-25 16:53:09 --- STRACE: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin/blocks/V_...')
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(30): Kohana_View->__construct('admin/blocks/V_...', NULL)
#2 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/index.php(7): Kohana_View::factory('admin/blocks/V_...')
#3 [internal function]: Controller_Admin_Index->action_index()
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#8 {main}
2012-05-25 16:53:13 --- ERROR: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-05-25 16:53:13 --- STRACE: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin/blocks/V_...')
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(30): Kohana_View->__construct('admin/blocks/V_...', NULL)
#2 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/index.php(7): Kohana_View::factory('admin/blocks/V_...')
#3 [internal function]: Controller_Admin_Index->action_index()
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#8 {main}
2012-05-25 16:53:13 --- ERROR: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-05-25 16:53:13 --- STRACE: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin/blocks/V_...')
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(30): Kohana_View->__construct('admin/blocks/V_...', NULL)
#2 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/index.php(7): Kohana_View::factory('admin/blocks/V_...')
#3 [internal function]: Controller_Admin_Index->action_index()
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#8 {main}
2012-05-25 16:53:13 --- ERROR: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-05-25 16:53:13 --- STRACE: View_Exception [ 0 ]: The requested view admin/blocks/V_index could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin/blocks/V_...')
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(30): Kohana_View->__construct('admin/blocks/V_...', NULL)
#2 /Applications/MAMP/htdocs/frontend/application/classes/controller/admin/index.php(7): Kohana_View::factory('admin/blocks/V_...')
#3 [internal function]: Controller_Admin_Index->action_index()
#4 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#8 {main}
2012-05-25 16:53:30 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 16:53:30 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 16:53:31 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 16:53:31 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 16:53:32 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 16:53:32 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 16:53:32 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 16:53:32 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 16:53:33 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 16:53:33 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 16:53:47 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
2012-05-25 16:53:47 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 73 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(73): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 73, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 16:56:59 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 16:56:59 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 16:57:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-25 16:57:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/index was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-25 20:32:50 --- ERROR: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 119 ]
2012-05-25 20:32:50 --- STRACE: ErrorException [ 8 ]: Undefined variable: main ~ APPPATH/views/admin/index.php [ 119 ]
--
#0 /Applications/MAMP/htdocs/frontend/application/views/admin/index.php(119): Kohana_Core::error_handler(8, 'Undefined varia...', '/Applications/M...', 119, Array)
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(61): include('/Applications/M...')
#2 /Applications/MAMP/htdocs/frontend/system/classes/kohana/view.php(343): Kohana_View::capture('/Applications/M...', Array)
#3 /Applications/MAMP/htdocs/frontend/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-25 20:38:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-icons_222222_256x240.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-25 20:38:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-25 20:38:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-icons_222222_256x240.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-25 20:38:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}