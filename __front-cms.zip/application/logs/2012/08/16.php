<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-08-16 12:02:22 --- ERROR: Session_Exception [ 1 ]: Error reading session data. ~ SYSPATH\classes\kohana\session.php [ 326 ]
2012-08-16 12:02:22 --- STRACE: Session_Exception [ 1 ]: Error reading session data. ~ SYSPATH\classes\kohana\session.php [ 326 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\session.php(125): Kohana_Session->read(NULL)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\session\database.php(74): Kohana_Session->__construct(Array, NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\session.php(54): Kohana_Session_Database->__construct(Array, NULL)
#3 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('database')
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#5 C:\wamp\www\frontend\application\classes\controller\admin\main.php(9): Kohana_Auth::instance()
#6 [internal function]: Controller_Admin_Main->before()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 12:33:21 --- ERROR: ErrorException [ 1 ]: Class 'Session_Database' not found ~ SYSPATH\classes\kohana\session.php [ 54 ]
2012-08-16 12:33:21 --- STRACE: ErrorException [ 1 ]: Class 'Session_Database' not found ~ SYSPATH\classes\kohana\session.php [ 54 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 12:38:14 --- ERROR: ErrorException [ 1 ]: Class 'Session_Database' not found ~ SYSPATH\classes\kohana\session.php [ 54 ]
2012-08-16 12:38:14 --- STRACE: ErrorException [ 1 ]: Class 'Session_Database' not found ~ SYSPATH\classes\kohana\session.php [ 54 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 12:38:32 --- ERROR: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\bootstrap.php [ 99 ]
2012-08-16 12:38:32 --- STRACE: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\bootstrap.php [ 99 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 13:05:10 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\config\database\reader.php [ 26 ]
2012-08-16 13:05:10 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\config\database\reader.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 13:07:17 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\config\database\reader.php [ 26 ]
2012-08-16 13:07:17 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\config\database\reader.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 13:07:19 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\config\database\reader.php [ 26 ]
2012-08-16 13:07:19 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\config\database\reader.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 13:09:10 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\config\database\reader.php [ 26 ]
2012-08-16 13:09:10 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\config\database\reader.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 13:38:48 --- ERROR: ErrorException [ 1 ]: Class 'Auth_Cookie' not found ~ MODPATH\auth\classes\kohana\auth.php [ 37 ]
2012-08-16 13:38:48 --- STRACE: ErrorException [ 1 ]: Class 'Auth_Cookie' not found ~ MODPATH\auth\classes\kohana\auth.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 13:44:25 --- ERROR: Session_Exception [ 1 ]: Error reading session data. ~ SYSPATH\classes\kohana\session.php [ 326 ]
2012-08-16 13:44:25 --- STRACE: Session_Exception [ 1 ]: Error reading session data. ~ SYSPATH\classes\kohana\session.php [ 326 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\session.php(125): Kohana_Session->read(NULL)
#1 C:\wamp\www\frontend\system\classes\kohana\session.php(54): Kohana_Session->__construct(Array, NULL)
#2 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('cookie')
#3 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#4 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(8): Kohana_Auth::instance()
#5 [internal function]: Controller_Admin_Auth->action_index()
#6 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#7 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#10 {main}
2012-08-16 13:44:32 --- ERROR: Kohana_Exception [ 0 ]: No encryption key is defined in the encryption configuration group: default ~ SYSPATH\classes\kohana\encrypt.php [ 68 ]
2012-08-16 13:44:35 --- ERROR: Kohana_Exception [ 0 ]: No encryption key is defined in the encryption configuration group: default ~ SYSPATH\classes\kohana\encrypt.php [ 68 ]
2012-08-16 13:44:44 --- ERROR: Kohana_Exception [ 0 ]: No encryption key is defined in the encryption configuration group: default ~ SYSPATH\classes\kohana\encrypt.php [ 68 ]
2012-08-16 13:44:52 --- ERROR: Kohana_Exception [ 0 ]: No encryption key is defined in the encryption configuration group: default ~ SYSPATH\classes\kohana\encrypt.php [ 68 ]
2012-08-16 13:45:00 --- ERROR: Kohana_Exception [ 0 ]: No encryption key is defined in the encryption configuration group: default ~ SYSPATH\classes\kohana\encrypt.php [ 68 ]
2012-08-16 13:46:28 --- ERROR: Kohana_Exception [ 0 ]: No encryption key is defined in the encryption configuration group: default ~ SYSPATH\classes\kohana\encrypt.php [ 68 ]
2012-08-16 13:48:38 --- ERROR: Kohana_Exception [ 0 ]: No encryption key is defined in the encryption configuration group: default ~ SYSPATH\classes\kohana\encrypt.php [ 68 ]
2012-08-16 14:05:16 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
2012-08-16 14:05:16 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 14:32:37 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\database.php [ 352 ]
2012-08-16 14:32:37 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\database.php [ 352 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 14:32:46 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\database.php [ 352 ]
2012-08-16 14:32:46 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\database.php [ 352 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 14:33:31 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\database.php [ 352 ]
2012-08-16 14:33:31 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ MODPATH\database\classes\kohana\database.php [ 352 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 14:47:31 --- ERROR: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
2012-08-16 14:47:31 --- STRACE: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\session.php(109): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 109, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\session\database.php(74): Kohana_Session->__construct(Array, NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\session.php(54): Kohana_Session_Database->__construct(Array, NULL)
#3 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('database')
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth::instance()
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 14:47:44 --- ERROR: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
2012-08-16 14:47:44 --- STRACE: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\session.php(109): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 109, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\session\database.php(74): Kohana_Session->__construct(Array, NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\session.php(54): Kohana_Session_Database->__construct(Array, NULL)
#3 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('database')
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth::instance()
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 14:49:07 --- ERROR: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
2012-08-16 14:49:07 --- STRACE: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\session.php(109): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 109, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\session\database.php(74): Kohana_Session->__construct(Array, NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\session.php(54): Kohana_Session_Database->__construct(Array, NULL)
#3 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('database')
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth::instance()
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 15:00:48 --- ERROR: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
2012-08-16 15:00:48 --- STRACE: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:03:52 --- ERROR: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
2012-08-16 15:03:52 --- STRACE: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:06:47 --- ERROR: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
2012-08-16 15:06:47 --- STRACE: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:07:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
2012-08-16 15:07:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(13): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 13, Array)
#1 [internal function]: Controller_Admin_Auth->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 15:07:14 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '[', expecting ',' or ';' ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
2012-08-16 15:07:14 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '[', expecting ',' or ';' ~ APPPATH\classes\controller\admin\auth.php [ 13 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:13:31 --- ERROR: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\bootstrap.php [ 117 ]
2012-08-16 15:13:31 --- STRACE: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\bootstrap.php [ 117 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:14:44 --- ERROR: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\bootstrap.php [ 117 ]
2012-08-16 15:14:44 --- STRACE: ErrorException [ 1 ]: Call to a member function set() on a non-object ~ APPPATH\bootstrap.php [ 117 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:25:46 --- ERROR: ErrorException [ 8 ]: Object of class Kohana_Config could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
2012-08-16 15:25:46 --- STRACE: ErrorException [ 8 ]: Object of class Kohana_Config could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\session.php(109): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 109, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\session\database.php(74): Kohana_Session->__construct(Array, NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\session.php(54): Kohana_Session_Database->__construct(Array, NULL)
#3 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('database')
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth::instance()
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 15:26:06 --- ERROR: ErrorException [ 8 ]: Object of class Kohana_Config could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
2012-08-16 15:26:06 --- STRACE: ErrorException [ 8 ]: Object of class Kohana_Config could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\session.php(109): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 109, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\session\database.php(74): Kohana_Session->__construct(Array, NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\session.php(54): Kohana_Session_Database->__construct(Array, NULL)
#3 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('database')
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth::instance()
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 15:27:28 --- ERROR: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
2012-08-16 15:27:28 --- STRACE: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\session.php(109): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 109, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\session\database.php(74): Kohana_Session->__construct(Array, NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\session.php(54): Kohana_Session_Database->__construct(Array, NULL)
#3 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('database')
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth::instance()
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 15:27:39 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
2012-08-16 15:27:39 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:27:44 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
2012-08-16 15:27:44 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:27:46 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
2012-08-16 15:27:46 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:28:02 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
2012-08-16 15:28:02 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:28:06 --- ERROR: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
2012-08-16 15:28:06 --- STRACE: ErrorException [ 1 ]: Maximum function nesting level of '100' reached, aborting! ~ SYSPATH\classes\kohana\core.php [ 44 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 15:50:31 --- ERROR: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
2012-08-16 15:50:31 --- STRACE: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ SYSPATH\classes\kohana\session.php [ 109 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\session.php(109): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 109, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\session\database.php(74): Kohana_Session->__construct(Array, NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\session.php(54): Kohana_Session_Database->__construct(Array, NULL)
#3 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('database')
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#5 C:\wamp\www\frontend\application\classes\controller\admin\main.php(9): Kohana_Auth::instance()
#6 [internal function]: Controller_Admin_Main->before()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:03:23 --- ERROR: ErrorException [ 8 ]: unserialize() [function.unserialize]: Error at offset 0 of 1 bytes ~ MODPATH\database\classes\kohana\config\database\reader.php [ 51 ]
2012-08-16 16:03:23 --- STRACE: ErrorException [ 8 ]: unserialize() [function.unserialize]: Error at offset 0 of 1 bytes ~ MODPATH\database\classes\kohana\config\database\reader.php [ 51 ]
--
#0 [internal function]: Kohana_Core::error_handler(8, 'unserialize() [...', 'C:\wamp\www\fro...', 51, Array)
#1 [internal function]: unserialize('0')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\config\database\reader.php(51): array_map('unserialize', Array)
#3 C:\wamp\www\frontend\modules\database\classes\kohana\config\database\writer.php(26): Kohana_Config_Database_Reader->load('site')
#4 C:\wamp\www\frontend\system\classes\kohana\config.php(124): Kohana_Config_Database_Writer->load('site')
#5 C:\wamp\www\frontend\application\config\session.php(16): Kohana_Config->load('site.session')
#6 C:\wamp\www\frontend\system\classes\kohana\core.php(792): include('C:\wamp\www\fro...')
#7 C:\wamp\www\frontend\system\classes\kohana\config\file\reader.php(49): Kohana_Core::load('C:\wamp\www\fro...')
#8 C:\wamp\www\frontend\system\classes\kohana\config.php(124): Kohana_Config_File_Reader->load('session')
#9 C:\wamp\www\frontend\system\classes\kohana\session.php(48): Kohana_Config->load('session')
#10 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(57): Kohana_Session::instance('database')
#11 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(37): Kohana_Auth->__construct(Object(Config_Group))
#12 C:\wamp\www\frontend\application\classes\controller\admin\main.php(9): Kohana_Auth::instance()
#13 [internal function]: Controller_Admin_Main->before()
#14 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#15 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#16 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#17 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#18 {main}
2012-08-16 16:09:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 12 ]
2012-08-16 16:09:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 12 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(12): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 12, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(54): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:09:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 12 ]
2012-08-16 16:09:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 12 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(12): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 12, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(54): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:14:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: option ~ APPPATH\views\admin\blocks\V_options.php [ 11 ]
2012-08-16 16:14:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: option ~ APPPATH\views\admin\blocks\V_options.php [ 11 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(11): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 11, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(54): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:31:10 --- ERROR: Database_Exception [ 1146 ]: Table 'frontend.options' doesn't exist [ SHOW FULL COLUMNS FROM `options` ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-16 16:31:10 --- STRACE: Database_Exception [ 1146 ]: Table 'frontend.options' doesn't exist [ SHOW FULL COLUMNS FROM `options` ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql.php(360): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1504): Kohana_Database_MySQL->list_columns('options')
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(392): Kohana_ORM->list_columns(true)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(337): Kohana_ORM->reload_columns()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(246): Kohana_ORM->_initialize()
#5 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#6 C:\wamp\www\frontend\application\classes\controller\admin\main.php(24): Kohana_ORM::factory('option', 1)
#7 [internal function]: Controller_Admin_Main->action_index()
#8 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#9 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#12 {main}
2012-08-16 16:31:47 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'option.id' in 'where clause' [ SELECT `option`.* FROM `config` AS `option` WHERE `option`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-16 16:31:47 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'option.id' in 'where clause' [ SELECT `option`.* FROM `config` AS `option` WHERE `option`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `option`...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\main.php(24): Kohana_ORM::factory('option', 1)
#6 [internal function]: Controller_Admin_Main->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:32:06 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'option.id' in 'where clause' [ SELECT `option`.* FROM `config` AS `option` WHERE `option`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-16 16:32:06 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'option.id' in 'where clause' [ SELECT `option`.* FROM `config` AS `option` WHERE `option`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `option`...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\main.php(24): Kohana_ORM::factory('option', 1)
#6 [internal function]: Controller_Admin_Main->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:32:19 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'option.id' in 'where clause' [ SELECT `option`.* FROM `config` AS `option` WHERE `option`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-16 16:32:19 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'option.id' in 'where clause' [ SELECT `option`.* FROM `config` AS `option` WHERE `option`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `option`...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\main.php(24): Kohana_ORM::factory('option', 1)
#6 [internal function]: Controller_Admin_Main->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:32:22 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'option.id' in 'where clause' [ SELECT `option`.* FROM `config` AS `option` WHERE `option`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-16 16:32:22 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'option.id' in 'where clause' [ SELECT `option`.* FROM `config` AS `option` WHERE `option`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `option`...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\main.php(24): Kohana_ORM::factory('option', 1)
#6 [internal function]: Controller_Admin_Main->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:33:17 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 11 ]
2012-08-16 16:33:17 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 11 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(11): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 11, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(55): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:33:22 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 11 ]
2012-08-16 16:33:22 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 11 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(11): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 11, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(55): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:34:26 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 11 ]
2012-08-16 16:34:26 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 11 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(11): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 11, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(56): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:37:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: hostname ~ APPPATH\classes\controller\admin\options.php [ 47 ]
2012-08-16 16:37:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: hostname ~ APPPATH\classes\controller\admin\options.php [ 47 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(47): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 47, Array)
#1 [internal function]: Controller_Admin_Options->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 16:45:14 --- ERROR: ErrorException [ 1 ]: Call to undefined method Config_Group::load() ~ APPPATH\classes\controller\admin\options.php [ 37 ]
2012-08-16 16:45:14 --- STRACE: ErrorException [ 1 ]: Call to undefined method Config_Group::load() ~ APPPATH\classes\controller\admin\options.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 16:45:18 --- ERROR: ErrorException [ 1 ]: Call to undefined method Config_Group::load() ~ APPPATH\classes\controller\admin\options.php [ 37 ]
2012-08-16 16:45:18 --- STRACE: ErrorException [ 1 ]: Call to undefined method Config_Group::load() ~ APPPATH\classes\controller\admin\options.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-16 16:45:58 --- ERROR: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ APPPATH\views\admin\blocks\V_options.php [ 67 ]
2012-08-16 16:45:58 --- STRACE: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ APPPATH\views\admin\blocks\V_options.php [ 67 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(67): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 67, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(57): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:49:09 --- ERROR: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-08-16 16:49:09 --- STRACE: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(50): Kohana_ORM->__get('sitename')
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 16:49:12 --- ERROR: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-08-16 16:49:12 --- STRACE: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(50): Kohana_ORM->__get('sitename')
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 16:50:10 --- ERROR: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-08-16 16:50:10 --- STRACE: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(50): Kohana_ORM->__get('sitename')
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 16:50:11 --- ERROR: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-08-16 16:50:11 --- STRACE: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(50): Kohana_ORM->__get('sitename')
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 16:50:40 --- ERROR: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-08-16 16:50:40 --- STRACE: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(50): Kohana_ORM->__get('sitename')
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 16:50:42 --- ERROR: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-08-16 16:50:42 --- STRACE: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(50): Kohana_ORM->__get('sitename')
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 16:50:48 --- ERROR: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-08-16 16:50:48 --- STRACE: Kohana_Exception [ 0 ]: The sitename property does not exist in the Model_Option class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(50): Kohana_ORM->__get('sitename')
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 16:54:23 --- ERROR: ErrorException [ 8 ]: Undefined variable: debug ~ APPPATH\classes\controller\site\home.php [ 57 ]
2012-08-16 16:54:23 --- STRACE: ErrorException [ 8 ]: Undefined variable: debug ~ APPPATH\classes\controller\site\home.php [ 57 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(57): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 57, Array)
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 16:54:37 --- ERROR: ErrorException [ 8 ]: Undefined variable: opt ~ APPPATH\views\site\index.php [ 7 ]
2012-08-16 16:54:37 --- STRACE: ErrorException [ 8 ]: Undefined variable: opt ~ APPPATH\views\site\index.php [ 7 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 7, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\home.php(69): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Home->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:55:29 --- ERROR: ErrorException [ 8 ]: Undefined variable: opt ~ APPPATH\views\site\index.php [ 7 ]
2012-08-16 16:55:29 --- STRACE: ErrorException [ 8 ]: Undefined variable: opt ~ APPPATH\views\site\index.php [ 7 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 7, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\home.php(63): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Home->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:55:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: opt ~ APPPATH\views\site\index.php [ 7 ]
2012-08-16 16:55:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: opt ~ APPPATH\views\site\index.php [ 7 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 7, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\home.php(65): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Home->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:56:23 --- ERROR: ErrorException [ 8 ]: Undefined variable: robots ~ APPPATH\views\site\index.php [ 12 ]
2012-08-16 16:56:23 --- STRACE: ErrorException [ 8 ]: Undefined variable: robots ~ APPPATH\views\site\index.php [ 12 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(12): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 12, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\home.php(65): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Home->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-16 16:57:13 --- ERROR: Database_Exception [ 1146 ]: Table 'frontend.options' doesn't exist [ SELECT status FROM options ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-16 16:57:13 --- STRACE: Database_Exception [ 1146 ]: Table 'frontend.options' doesn't exist [ SELECT status FROM options ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT status F...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\site\page.php(7): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Site_Page->before()
#3 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Page))
#4 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#7 {main}
2012-08-16 16:57:20 --- ERROR: Database_Exception [ 1146 ]: Table 'frontend.options' doesn't exist [ SELECT status FROM options ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-16 16:57:20 --- STRACE: Database_Exception [ 1146 ]: Table 'frontend.options' doesn't exist [ SELECT status FROM options ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT status F...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\site\page.php(7): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Site_Page->before()
#3 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Page))
#4 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#7 {main}
2012-08-16 16:58:38 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-16 16:58:38 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 17:15:56 --- ERROR: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ APPPATH\classes\controller\site\home.php [ 9 ]
2012-08-16 17:15:56 --- STRACE: ErrorException [ 8 ]: Object of class Config_Group could not be converted to int ~ APPPATH\classes\controller\site\home.php [ 9 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(9): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 9, Array)
#1 [internal function]: Controller_Site_Home->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-16 17:18:04 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL offline was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-08-16 17:18:04 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL offline was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-08-16 17:18:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL offline was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-08-16 17:18:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL offline was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-08-16 17:18:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL offline was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-08-16 17:18:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL offline was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}