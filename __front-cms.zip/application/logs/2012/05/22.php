<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-05-22 00:00:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:00:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]26 ]
2012-05-22 00:00:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:00:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:04:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:04:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:04:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:04:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:05:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:05:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:05:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:05:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:05:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:05:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:05:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:05:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:06:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:06:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:06:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:06:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:06:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:06:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:06:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:06:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:10:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:10:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:10:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:10:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:11:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:11:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:11:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:11:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:11:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:11:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:11:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:11:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:12:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:12:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:12:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:12:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:13:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:13:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:13:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:13:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:13:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:13:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:13:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:13:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:13:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:13:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:13:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:13:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:13:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:13:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:13:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:13:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:13:55 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 00:13:55 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:14:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 00:14:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:14:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:14:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:14:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:14:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:14:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 00:14:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:20:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:20:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:20:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:20:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:20:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:20:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:20:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:20:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:20:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:20:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:21:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:21:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:26:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:26:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:27:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:27:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:28:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:28:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:28:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:28:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:28:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:28:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:28:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:28:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:29:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:29:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:29:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:29:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:30:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:30:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:30:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:30:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:30:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:30:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:30:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:30:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:30:08 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 00:30:08 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:32:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:32:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:32:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:32:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:32:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:32:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:32:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:32:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:32:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:32:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:32:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:32:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:36:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:36:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:36:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:36:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:38:09 --- ERROR: ErrorException [ 2048 ]: Only variables should be passed by reference ~ APPPATH\classes\controller\admin\main.php [ 10 ]
2012-05-22 00:38:09 --- STRACE: ErrorException [ 2048 ]: Only variables should be passed by reference ~ APPPATH\classes\controller\admin\main.php [ 10 ]
--
#0 C:\wamp\www\front-end\application\classes\controller\admin\main.php(10): Kohana_Core::error_handler(2048, 'Only variables ...', 'C:\wamp\www\fro...', 10, Array)
#1 [internal function]: Controller_Admin_Main->before()
#2 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#6 {main}
2012-05-22 00:38:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:38:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:38:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:38:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:42:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:42:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:42:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:42:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:42:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/blocks/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 00:42:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/blocks/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:42:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/blocks/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 00:42:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/blocks/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:43:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:43:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:43:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:43:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:43:16 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL blocks/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 00:43:16 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL blocks/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:43:20 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL blocks/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 00:43:20 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL blocks/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:43:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:43:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:43:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:43:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:43:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 00:43:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:44:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:44:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:44:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL main/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-05-22 00:44:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL main/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 00:45:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:45:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:45:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:46:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:46:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:46:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:46:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:46:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:46:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:46:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:46:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:46:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:46:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:46:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:46:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:47:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:47:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:47:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:47:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:48:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:48:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:48:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:48:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:49:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:49:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:49:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:49:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:57:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:57:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:57:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:57:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:57:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:57:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 00:58:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 00:58:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:03:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:03:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:03:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:03:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:03:47 --- ERROR: View_Exception [ 0 ]: The requested view template could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-05-22 01:03:47 --- STRACE: View_Exception [ 0 ]: The requested view template could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\view.php(137): Kohana_View->set_filename('template')
#1 C:\wamp\www\front-end\system\classes\kohana\view.php(30): Kohana_View->__construct('template', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\controller\template.php(33): Kohana_View::factory('template')
#3 C:\wamp\www\front-end\application\classes\controller\admin\main.php(7): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\front-end\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#9 {main}
2012-05-22 01:03:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:03:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:03:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:03:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:05:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:05:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:05:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:05:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:06:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:06:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:06:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:06:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:10:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:10:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:11:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:11:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:11:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:11:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:12:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:12:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:12:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:12:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:12:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:12:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:13:36 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
2012-05-22 01:13:36 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match() [<...', 'C:\wamp\www\fro...', 392, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\route.php(392): preg_match('#^admin(?:/(?P<...', 'admin', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\request.php(567): Kohana_Route->matches('admin')
#3 C:\wamp\www\front-end\system\classes\kohana\request.php(785): Kohana_Request::process_uri('admin', Array)
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(198): Kohana_Request->__construct('/admin', NULL)
#5 C:\wamp\www\front-end\index.php(108): Kohana_Request::factory()
#6 {main}
2012-05-22 01:13:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:13:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:13:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:13:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:16:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:16:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:18:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:18:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:18:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:18:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:18:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:18:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:18:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:18:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:18:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:18:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:18:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:18:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:18:55 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:18:55 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:19:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:19:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:19:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:19:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:19:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admi/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:19:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admi/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:19:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:19:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:19:34 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
2012-05-22 01:19:34 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match() [<...', 'C:\wamp\www\fro...', 392, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\route.php(392): preg_match('#^admin(?:/(?P<...', 'admin/options', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\request.php(567): Kohana_Route->matches('admin/options')
#3 C:\wamp\www\front-end\system\classes\kohana\request.php(785): Kohana_Request::process_uri('admin/options', Array)
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(198): Kohana_Request->__construct('/admin/options', NULL)
#5 C:\wamp\www\front-end\index.php(108): Kohana_Request::factory()
#6 {main}
2012-05-22 01:19:35 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
2012-05-22 01:19:35 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match() [<...', 'C:\wamp\www\fro...', 392, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\route.php(392): preg_match('#^admin(?:/(?P<...', 'admin/options', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\request.php(567): Kohana_Route->matches('admin/options')
#3 C:\wamp\www\front-end\system\classes\kohana\request.php(785): Kohana_Request::process_uri('admin/options', Array)
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(198): Kohana_Request->__construct('/admin/options', NULL)
#5 C:\wamp\www\front-end\index.php(108): Kohana_Request::factory()
#6 {main}
2012-05-22 01:19:51 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
2012-05-22 01:19:51 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match() [<...', 'C:\wamp\www\fro...', 392, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\route.php(392): preg_match('#^admin(?:/(?P<...', 'admin/main/opti...', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\request.php(567): Kohana_Route->matches('admin/main/opti...')
#3 C:\wamp\www\front-end\system\classes\kohana\request.php(785): Kohana_Request::process_uri('admin/main/opti...', Array)
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(198): Kohana_Request->__construct('/admin/main/opt...', NULL)
#5 C:\wamp\www\front-end\index.php(108): Kohana_Request::factory()
#6 {main}
2012-05-22 01:19:55 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
2012-05-22 01:19:55 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 62 ~ SYSPATH\classes\kohana\route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match() [<...', 'C:\wamp\www\fro...', 392, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\route.php(392): preg_match('#^admin(?:/(?P<...', 'admin', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\request.php(567): Kohana_Route->matches('admin')
#3 C:\wamp\www\front-end\system\classes\kohana\request.php(785): Kohana_Request::process_uri('admin', Array)
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(198): Kohana_Request->__construct('/admin', NULL)
#5 C:\wamp\www\front-end\index.php(108): Kohana_Request::factory()
#6 {main}
2012-05-22 01:20:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:20:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:20:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:20:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:21:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:21:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:21:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:21:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:21:59 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:21:59 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:23:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:23:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:23:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:23:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:23:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:23:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:23:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:23:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:23:45 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 79 ~ SYSPATH\classes\kohana\route.php [ 392 ]
2012-05-22 01:23:45 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 79 ~ SYSPATH\classes\kohana\route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match() [<...', 'C:\wamp\www\fro...', 392, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\route.php(392): preg_match('#^admin(?:/(?P<...', 'admin', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\request.php(567): Kohana_Route->matches('admin')
#3 C:\wamp\www\front-end\system\classes\kohana\request.php(785): Kohana_Request::process_uri('admin', Array)
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(198): Kohana_Request->__construct('/admin', NULL)
#5 C:\wamp\www\front-end\index.php(108): Kohana_Request::factory()
#6 {main}
2012-05-22 01:23:46 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 79 ~ SYSPATH\classes\kohana\route.php [ 392 ]
2012-05-22 01:23:46 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 79 ~ SYSPATH\classes\kohana\route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match() [<...', 'C:\wamp\www\fro...', 392, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\route.php(392): preg_match('#^admin(?:/(?P<...', 'admin', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\request.php(567): Kohana_Route->matches('admin')
#3 C:\wamp\www\front-end\system\classes\kohana\request.php(785): Kohana_Request::process_uri('admin', Array)
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(198): Kohana_Request->__construct('/admin', NULL)
#5 C:\wamp\www\front-end\index.php(108): Kohana_Request::factory()
#6 {main}
2012-05-22 01:23:53 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 79 ~ SYSPATH\classes\kohana\route.php [ 392 ]
2012-05-22 01:23:53 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 79 ~ SYSPATH\classes\kohana\route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match() [<...', 'C:\wamp\www\fro...', 392, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\route.php(392): preg_match('#^admin(?:/(?P<...', 'admin', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\request.php(567): Kohana_Route->matches('admin')
#3 C:\wamp\www\front-end\system\classes\kohana\request.php(785): Kohana_Request::process_uri('admin', Array)
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(198): Kohana_Request->__construct('/admin', NULL)
#5 C:\wamp\www\front-end\index.php(108): Kohana_Request::factory()
#6 {main}
2012-05-22 01:24:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:24:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:24:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:24:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:24:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:24:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:24:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:24:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:24:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:24:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:24:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:24:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:24:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:24:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:27:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:27:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:27:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:27:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:27:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:27:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:27:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:27:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:27:30 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 79 ~ SYSPATH\classes\kohana\route.php [ 392 ]
2012-05-22 01:27:30 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 79 ~ SYSPATH\classes\kohana\route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match() [<...', 'C:\wamp\www\fro...', 392, Array)
#1 C:\wamp\www\front-end\system\classes\kohana\route.php(392): preg_match('#^admin(?:/(?P<...', 'admin', NULL)
#2 C:\wamp\www\front-end\system\classes\kohana\request.php(567): Kohana_Route->matches('admin')
#3 C:\wamp\www\front-end\system\classes\kohana\request.php(785): Kohana_Request::process_uri('admin', Array)
#4 C:\wamp\www\front-end\system\classes\kohana\request.php(198): Kohana_Request->__construct('/admin', NULL)
#5 C:\wamp\www\front-end\index.php(108): Kohana_Request::factory()
#6 {main}
2012-05-22 01:28:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:28:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:28:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:28:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:28:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:28:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:28:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:28:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:28:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:28:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:28:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:28:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:28:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:28:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:28:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:28:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:28:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:28:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:28:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:28:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:28:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:28:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:28:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:28:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:28:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:28:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:29:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:29:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:29:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:29:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/css/bootstrap.css ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/css/bootstrap.css ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/css/jquery-ui-1.8.16.custom.css ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/css/jquery-ui-1.8.16.custom.css ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/jquery-1.7.2.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/underscore.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/underscore.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/less-1.3.0.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/less-1.3.0.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/bootstrap.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/bootstrap.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/modernizr-2.5.3.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/modernizr-2.5.3.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/json2.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/json2.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/backbone.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/backbone.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/user.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/user.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/addcat.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/addcat.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/add.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/add.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/user.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/user.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/jquery-1.7.2.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/jquery-1.7.2.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/email.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/email.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/info.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/info.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/stats.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/stats.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/rss.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/rss.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/image.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/image.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/youtube.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/youtube.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/trash.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/trash.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/bootstrap.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/bootstrap.min.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/modernizr-2.5.3.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/modernizr-2.5.3.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/underscore.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/underscore.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/backbone.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/backbone.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/json2.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/json2.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/user.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/js/user.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/rss.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/rss.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/add.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/add.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/addcat.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/addcat.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/user.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/user.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/email.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/email.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/stats.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/stats.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/trash.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/trash.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/info.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/info.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/image.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/image.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/youtube.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/youtube.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/favicon.ico ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/favicon.ico ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/favicon.ico ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/favicon.ico ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/favicon.ico ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/assets/img/favicon.ico ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/index.php/admin/options ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/index.php/admin/options ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:32:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:32:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:33:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:33:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:33:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:33:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:33:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:33:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:33:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:33:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:33:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:33:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:34:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:34:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:34:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:34:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:34:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:34:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:34:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:34:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:34:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:34:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:34:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:34:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:34:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:34:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:34:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:34:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:34:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:34:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:36:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:36:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:36:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:36:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:36:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:36:47 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:36:47 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:43:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:43:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:43:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:43:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:43:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:43:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:43:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:43:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:43:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:43:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:43:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:43:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:43:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:43:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:43:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:43:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:43:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:43:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:43:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:43:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:43:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:43:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:43:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:43:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:43:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:43:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:44:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:44:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:44:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:44:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:44:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:44:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:44:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:44:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:44:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:44:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:44:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:44:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:44:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:44:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:44:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:44:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:44:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:44:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:44:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:44:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:44:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:44:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:44:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:44:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:45:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:45:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:45:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:45:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:45:25 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:45:25 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:45:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:45:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:45:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:45:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:45:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:45:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:45:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:45:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:45:40 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:45:40 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:45:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:45:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:45:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:45:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:45:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:45:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:45:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:45:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:46:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:46:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:46:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:46:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:46:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/moduless was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-22 01:47:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/moduless was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-22 01:47:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:47:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:47:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:48:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:48:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:49:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:49:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:50:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:50:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:51:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:51:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 01:51:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 01:51:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:02:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:02:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:10:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:10:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:10:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:10:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:12:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:12:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:12:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:12:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:12:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:12:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:12:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:12:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:12:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:12:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:12:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:12:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:14:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:14:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:14:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:14:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:14:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:14:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:14:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:14:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:15:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:15:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:15:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:15:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:15:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:15:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:15:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:15:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:15:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:15:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:15:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:15:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:15:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:15:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:15:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:15:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:17:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:17:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:17:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:17:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:17:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:17:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:17:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:17:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:18:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:18:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:18:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:18:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:18:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:18:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:18:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:18:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:19:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:19:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:19:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:19:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:22:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:22:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:22:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:22:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:23:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:23:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:23:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:23:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:24:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:24:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:24:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:24:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:25:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:25:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:25:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:25:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:26:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:26:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:26:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:26:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-22 22:26:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-22 22:26:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}