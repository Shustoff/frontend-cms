<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-06-04 03:58:09 --- ERROR: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 03:58:09 --- STRACE: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(20): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 03:58:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 03:58:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(20): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 03:58:15 --- ERROR: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 03:58:15 --- STRACE: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(20): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 03:58:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 03:58:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(20): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:09:19 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:09:19 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:09:21 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:09:21 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:09:21 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:09:21 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:09:21 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:09:21 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:09:24 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:09:24 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:09:25 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:09:25 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:09:25 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:09:25 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:09:30 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:09:30 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:11:35 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:11:35 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:11:37 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:11:37 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:11:38 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:11:38 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:11:38 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:11:38 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:11:39 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:11:39 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:11:47 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:47 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:11:49 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:49 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:11:51 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:51 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:11:51 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:51 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:11:51 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:51 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:11:51 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:51 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:11:51 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:51 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:11:54 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:54 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:11:54 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:54 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:11:54 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:11:54 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:12:54 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:12:54 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:12:56 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:12:56 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:12:57 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:12:57 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:12:57 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:12:57 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:12:57 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:12:57 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:12:59 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:12:59 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:12:59 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:12:59 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:12:59 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:12:59 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:13:43 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:13:43 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:13:45 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:13:45 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:13:47 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:13:47 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:13:47 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:13:47 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:14:04 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:14:04 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:14:05 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:14:05 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:14:05 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:14:05 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:14:06 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:14:06 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:14:07 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:14:07 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:14:07 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 04:14:07 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:14:22 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:14:22 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:14:23 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:14:23 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:14:23 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:14:23 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:20:25 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:20:25 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(25): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:20:26 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:20:26 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(25): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:23:35 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:23:35 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(26): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:23:36 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:23:36 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(26): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:23:37 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:23:37 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(26): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:23:38 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:23:38 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(26): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:27:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:27:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:27:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:27:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:27:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:27:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:28:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:28:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:28:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:28:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:28:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:28:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:32:11 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:32:11 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:32:12 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:32:12 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:32:12 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:32:12 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:32:13 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:32:13 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:34:59 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:34:59 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:35:01 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:35:01 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:35:01 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:35:01 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Options as array ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 04:35:26 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:35:26 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:35:27 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:35:27 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:35:27 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:35:27 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:35:28 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:35:28 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:35:39 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:35:39 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:35:39 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:35:39 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:35:40 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:35:40 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:35:41 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:35:41 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:35:42 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:35:42 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:35:42 --- ERROR: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
2012-06-04 04:35:42 --- STRACE: ErrorException [ 2 ]: mysql_data_seek() expects parameter 2 to be long, string given ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_data_seek...', 'C:\wamp\www\fro...', 33, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(33): mysql_data_seek(Resource id #94, 'sitename')
#2 C:\wamp\www\frontend\modules\database\classes\kohana\database\result.php(236): Kohana_Database_MySQL_Result->seek('sitename')
#3 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Database_Result->offsetGet('sitename')
#4 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#7 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#8 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#9 [internal function]: Controller_Admin_Options->action_index()
#10 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#11 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#14 {main}
2012-06-04 04:40:33 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:40:33 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:40:33 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:40:33 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:40:35 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:40:35 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:40:35 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:40:35 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:40:37 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:40:37 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:40:37 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:40:37 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:40:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:40:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:40:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:40:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(24): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:45:13 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:45:13 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:45:15 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
2012-06-04 04:45:15 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(8): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 8, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:48:40 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:48:40 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:48:41 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:48:41 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:48:42 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:48:42 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:50:08 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:50:08 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:50:09 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:50:09 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:50:10 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:50:10 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:50:11 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:50:11 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:50:11 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:50:11 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:51:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:51:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:51:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:51:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:51:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:51:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:51:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 04:51:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 04:57:18 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\classes\controller\admin\options.php [ 14 ]
2012-06-04 04:57:18 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\classes\controller\admin\options.php [ 14 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(14): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 14, Array)
#1 [internal function]: Controller_Admin_Options->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 04:57:19 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\classes\controller\admin\options.php [ 14 ]
2012-06-04 04:57:19 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\classes\controller\admin\options.php [ 14 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(14): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 14, Array)
#1 [internal function]: Controller_Admin_Options->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 05:02:03 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:03 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:04 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:04 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:04 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:04 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:04 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:04 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:05 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:05 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:05 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:05 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:26 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:26 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:27 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:27 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:28 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:28 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:30 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:30 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:30 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:30 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:41 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:41 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:42 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:42 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:42 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:42 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:44 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:44 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:44 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:44 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:44 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:44 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:45 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:45 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:02:45 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-06-04 05:02:45 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'options.id' in 'where clause' [ SELECT `options`.* FROM `options` AS `options` WHERE `options`.`id` = 1 LIMIT 1 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `options...', false, Array)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(898): Kohana_ORM->_load_result(false)
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(263): Kohana_ORM->find()
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(1)
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM::factory('options', 1)
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:13:12 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:13:12 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:13:12 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:13:12 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:13:13 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:13:13 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:13:15 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:13:15 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:13:15 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:13:15 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:13:16 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:13:16 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:13:16 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:13:16 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:14:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:14:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:14:55 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:14:55 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 05:14:55 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 05:14:55 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:13:08 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:13:08 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:13:11 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:13:11 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:13:18 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:13:18 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:13:19 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:13:19 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:13:20 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:13:20 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:13:32 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:13:32 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:13:33 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:13:33 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:16:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:16:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:16:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:16:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:16:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:16:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:16:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:16:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:14 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:14 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:16 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:16 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:16 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:16 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:20 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:20 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:20 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:20 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:20 --- ERROR: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:20 --- STRACE: ErrorException [ 8 ]: Undefined index: sitename ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:18:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:18:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:22:19 --- ERROR: ErrorException [ 8 ]: Undefined variable: option ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:22:19 --- STRACE: ErrorException [ 8 ]: Undefined variable: option ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 15:22:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: option ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-04 15:22:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: option ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 16:50:50 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_LNUMBER, expecting T_STRING or T_VARIABLE or '{' or '$' ~ APPPATH\views\admin\blocks\V_options.php [ 56 ]
2012-06-04 16:50:50 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_LNUMBER, expecting T_STRING or T_VARIABLE or '{' or '$' ~ APPPATH\views\admin\blocks\V_options.php [ 56 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-04 16:51:41 --- ERROR: Kohana_Exception [ 0 ]: The page404 property does not exist in the Model_Options class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-06-04 16:51:41 --- STRACE: Kohana_Exception [ 0 ]: The page404 property does not exist in the Model_Options class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(56): Kohana_ORM->__get('page404')
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 16:51:42 --- ERROR: Kohana_Exception [ 0 ]: The page404 property does not exist in the Model_Options class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-06-04 16:51:42 --- STRACE: Kohana_Exception [ 0 ]: The page404 property does not exist in the Model_Options class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(56): Kohana_ORM->__get('page404')
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 16:51:42 --- ERROR: Kohana_Exception [ 0 ]: The page404 property does not exist in the Model_Options class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-06-04 16:51:42 --- STRACE: Kohana_Exception [ 0 ]: The page404 property does not exist in the Model_Options class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(56): Kohana_ORM->__get('page404')
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-04 17:19:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/save was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-06-04 17:19:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/save was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-06-04 17:26:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admi was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-06-04 17:26:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admi was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-06-04 17:29:40 --- ERROR: Kohana_Exception [ 0 ]: Cannot update options model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1250 ]
2012-06-04 17:29:40 --- STRACE: Kohana_Exception [ 0 ]: Cannot update options model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1250 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(30): Kohana_ORM->update()
#1 [internal function]: Controller_Admin_Options->action_save()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 17:31:44 --- ERROR: Kohana_Exception [ 0 ]: Cannot update options model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1250 ]
2012-06-04 17:31:44 --- STRACE: Kohana_Exception [ 0 ]: Cannot update options model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1250 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(30): Kohana_ORM->update()
#1 [internal function]: Controller_Admin_Options->action_save()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 17:35:44 --- ERROR: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
2012-06-04 17:35:44 --- STRACE: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM->find()
#1 [internal function]: Controller_Admin_Options->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 17:35:45 --- ERROR: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
2012-06-04 17:35:45 --- STRACE: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM->find()
#1 [internal function]: Controller_Admin_Options->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 17:35:46 --- ERROR: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
2012-06-04 17:35:46 --- STRACE: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM->find()
#1 [internal function]: Controller_Admin_Options->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 17:35:47 --- ERROR: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
2012-06-04 17:35:47 --- STRACE: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM->find()
#1 [internal function]: Controller_Admin_Options->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 17:35:47 --- ERROR: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
2012-06-04 17:35:47 --- STRACE: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(13): Kohana_ORM->find()
#1 [internal function]: Controller_Admin_Options->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 20:03:58 --- ERROR: ErrorException [ 8 ]: Undefined variable: topname ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:03:58 --- STRACE: ErrorException [ 8 ]: Undefined variable: topname ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:04:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: topname ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:04:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: topname ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:04:26 --- ERROR: ErrorException [ 8 ]: Undefined variable: topname ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:04:26 --- STRACE: ErrorException [ 8 ]: Undefined variable: topname ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:04:32 --- ERROR: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
2012-06-04 20:04:32 --- STRACE: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\main.php(23): Kohana_ORM->find_all()
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-04 20:04:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: topname ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:04:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: topname ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:04:53 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:04:53 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:04:54 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:04:54 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:06:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: admin/auth.ыва ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-06-04 20:06:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: admin/auth.ыва ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#1 {main}
2012-06-04 20:06:40 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/auth/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-06-04 20:06:40 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/auth/pages was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-06-04 20:09:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:09:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:09:24 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:09:24 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$sitename ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:12:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:12:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:13:10 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:13:10 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-04 20:19:57 --- ERROR: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\index.php [ 20 ]
2012-06-04 20:19:57 --- STRACE: ErrorException [ 8 ]: Undefined variable: sitename ~ APPPATH\views\admin\index.php [ 20 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(20): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 20, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}