<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-07-07 13:09:27 --- ERROR: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: YES) ~ MODPATH\database\classes\kohana\database\mysql.php [ 67 ]
2012-07-07 13:09:27 --- STRACE: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: YES) ~ MODPATH\database\classes\kohana\database\mysql.php [ 67 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql.php(171): Kohana_Database_MySQL->connect()
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql.php(360): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1504): Kohana_Database_MySQL->list_columns('users')
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(392): Kohana_ORM->list_columns(true)
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(337): Kohana_ORM->reload_columns()
#5 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(246): Kohana_ORM->_initialize()
#6 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(NULL)
#7 C:\wamp\www\frontend\modules\orm\classes\kohana\auth\orm.php(75): Kohana_ORM::factory('user')
#8 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(90): Kohana_Auth_ORM->_login('admin', 'admin123', false)
#9 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth->login('admin', 'admin123', false)
#10 [internal function]: Controller_Admin_Auth->action_index()
#11 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#12 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#14 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#15 {main}
2012-07-07 13:20:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-07-07 13:20:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#1 {main}
2012-07-07 13:35:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-07-07 13:35:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#1 {main}
2012-07-07 15:17:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/table/add was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-07-07 15:17:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/table/add was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-07-07 16:31:24 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Admin_Users::action_add() ~ APPPATH\classes\controller\admin\users.php [ 53 ]
2012-07-07 16:31:24 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Controller_Admin_Users::action_add() ~ APPPATH\classes\controller\admin\users.php [ 53 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\users.php(53): Kohana_Core::error_handler(2, 'Missing argumen...', 'C:\wamp\www\fro...', 53, Array)
#1 [internal function]: Controller_Admin_Users->action_add()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-07-07 16:34:19 --- ERROR: ErrorException [ 2048 ]: Declaration of Controller_Admin_Users::action_add() should be compatible with that of Controller_App::action_add() ~ APPPATH\classes\controller\admin\users.php [ 3 ]
2012-07-07 16:34:19 --- STRACE: ErrorException [ 2048 ]: Declaration of Controller_Admin_Users::action_add() should be compatible with that of Controller_App::action_add() ~ APPPATH\classes\controller\admin\users.php [ 3 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\users.php(3): Kohana_Core::error_handler(2048, 'Declaration of ...', 'C:\wamp\www\fro...', 3, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\core.php(496): require('C:\wamp\www\fro...')
#2 [internal function]: Kohana_Core::auto_load('controller_admi...')
#3 [internal function]: spl_autoload_call('controller_admi...')
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(85): class_exists('controller_admi...')
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-07-07 16:35:43 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Admin_Users::action_add() ~ APPPATH\classes\controller\admin\users.php [ 53 ]
2012-07-07 16:35:43 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Controller_Admin_Users::action_add() ~ APPPATH\classes\controller\admin\users.php [ 53 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\users.php(53): Kohana_Core::error_handler(2, 'Missing argumen...', 'C:\wamp\www\fro...', 53, Array)
#1 [internal function]: Controller_Admin_Users->action_add()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-07-07 16:42:05 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Admin_Users::action_add() ~ APPPATH\classes\controller\admin\users.php [ 53 ]
2012-07-07 16:42:05 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Controller_Admin_Users::action_add() ~ APPPATH\classes\controller\admin\users.php [ 53 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\users.php(53): Kohana_Core::error_handler(2, 'Missing argumen...', 'C:\wamp\www\fro...', 53, Array)
#1 [internal function]: Controller_Admin_Users->action_add()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-07-07 16:42:55 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-07-07 16:42:55 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1200): Kohana_ORM->check(Object(Validation))
#1 C:\wamp\www\frontend\modules\orm\classes\model\auth\user.php(167): Kohana_ORM->create(Object(Validation))
#2 C:\wamp\www\frontend\application\classes\controller\admin\users.php(56): Model_Auth_User->create_user(Array, NULL)
#3 [internal function]: Controller_Admin_Users->action_add()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-07-07 16:43:14 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-07-07 16:43:14 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1200): Kohana_ORM->check(Object(Validation))
#1 C:\wamp\www\frontend\modules\orm\classes\model\auth\user.php(167): Kohana_ORM->create(Object(Validation))
#2 C:\wamp\www\frontend\application\classes\controller\admin\users.php(56): Model_Auth_User->create_user(Array, NULL)
#3 [internal function]: Controller_Admin_Users->action_add()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-07-07 16:43:34 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-07-07 16:43:34 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1200): Kohana_ORM->check(Object(Validation))
#1 C:\wamp\www\frontend\modules\orm\classes\model\auth\user.php(167): Kohana_ORM->create(Object(Validation))
#2 C:\wamp\www\frontend\application\classes\controller\admin\users.php(56): Model_Auth_User->create_user(Array, NULL)
#3 [internal function]: Controller_Admin_Users->action_add()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-07-07 16:47:05 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Admin_Users::action_edit() ~ APPPATH\classes\controller\admin\users.php [ 87 ]
2012-07-07 16:47:05 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Controller_Admin_Users::action_edit() ~ APPPATH\classes\controller\admin\users.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\users.php(87): Kohana_Core::error_handler(2, 'Missing argumen...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Admin_Users->action_edit()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-07-07 16:47:19 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-07-07 16:47:19 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1261): Kohana_ORM->check(Object(Validation))
#1 C:\wamp\www\frontend\modules\orm\classes\model\auth\user.php(201): Kohana_ORM->update(Object(Validation))
#2 C:\wamp\www\frontend\application\classes\controller\admin\users.php(91): Model_Auth_User->update_user(Array, NULL)
#3 [internal function]: Controller_Admin_Users->action_edit()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-07-07 17:12:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-07-07 17:12:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#1 {main}
2012-07-07 17:13:38 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-07-07 17:13:38 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1200): Kohana_ORM->check(Object(Validation))
#1 C:\wamp\www\frontend\modules\orm\classes\model\auth\user.php(167): Kohana_ORM->create(Object(Validation))
#2 C:\wamp\www\frontend\application\classes\controller\admin\users.php(61): Model_Auth_User->create_user(Array, NULL)
#3 [internal function]: Controller_Admin_Users->action_add()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-07-07 17:28:01 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_IF, expecting T_STRING ~ APPPATH\classes\controller\admin\users.php [ 81 ]
2012-07-07 17:28:01 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_IF, expecting T_STRING ~ APPPATH\classes\controller\admin\users.php [ 81 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-07-07 17:28:03 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_IF, expecting T_STRING ~ APPPATH\classes\controller\admin\users.php [ 81 ]
2012-07-07 17:28:03 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_IF, expecting T_STRING ~ APPPATH\classes\controller\admin\users.php [ 81 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-07-07 17:48:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users/checkunique was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-07-07 17:48:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users/checkunique was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-07-07 17:48:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users/checkunique was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-07-07 17:48:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users/checkunique was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-07-07 17:50:07 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users/checkunique was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-07-07 17:50:07 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users/checkunique was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-07-07 17:51:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/users/checkunique was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-07-07 17:51:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/users/checkunique was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}