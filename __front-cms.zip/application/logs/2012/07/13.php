<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-07-13 11:58:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/styles.less ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-07-13 11:58:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/styles.less ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#1 {main}
2012-07-13 12:00:00 --- ERROR: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: YES) ~ MODPATH\database\classes\kohana\database\mysql.php [ 67 ]
2012-07-13 12:00:00 --- STRACE: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: YES) ~ MODPATH\database\classes\kohana\database\mysql.php [ 67 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql.php(171): Kohana_Database_MySQL->connect()
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql.php(360): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1504): Kohana_Database_MySQL->list_columns('users')
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(392): Kohana_ORM->list_columns(true)
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(337): Kohana_ORM->reload_columns()
#5 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(246): Kohana_ORM->_initialize()
#6 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(NULL)
#7 C:\wamp\www\frontend\modules\orm\classes\kohana\auth\orm.php(75): Kohana_ORM::factory('user')
#8 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(90): Kohana_Auth_ORM->_login('admin', 'admin123', false)
#9 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth->login('admin', 'admin123', false)
#10 [internal function]: Controller_Admin_Auth->action_index()
#11 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#12 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#14 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#15 {main}
2012-07-13 12:43:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL dfh was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-07-13 12:44:01 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL sdfwer was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-07-13 12:44:16 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL sdfwer was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-07-13 12:45:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL sdfwer was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-07-13 12:46:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL sdfwer was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-07-13 12:46:40 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL sdfwer was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]