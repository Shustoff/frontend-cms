<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-08-01 01:55:47 --- ERROR: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: YES) ~ MODPATH\database\classes\kohana\database\mysql.php [ 67 ]
2012-08-01 01:55:47 --- STRACE: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: YES) ~ MODPATH\database\classes\kohana\database\mysql.php [ 67 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql.php(171): Kohana_Database_MySQL->connect()
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(1, 'SELECT * FROM o...', false, Array)
#2 C:\wamp\www\frontend\application\classes\controller\site\main.php(9): Kohana_Database_Query->execute()
#3 [internal function]: Controller_Site_Main->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Main))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-01 01:57:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: catalog_id ~ APPPATH\classes\controller\site\page.php [ 21 ]
2012-08-01 01:57:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: catalog_id ~ APPPATH\classes\controller\site\page.php [ 21 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(21): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 21, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}