<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-09-05 00:14:55 --- ERROR: ErrorException [ 8 ]: Undefined index: author ~ APPPATH\views\site\index.php [ 16 ]
2012-09-05 00:14:55 --- STRACE: ErrorException [ 8 ]: Undefined index: author ~ APPPATH\views\site\index.php [ 16 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(16): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 16, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\home.php(59): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Home->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}