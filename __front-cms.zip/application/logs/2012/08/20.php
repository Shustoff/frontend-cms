<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-08-20 00:00:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
2012-08-20 00:00:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:00:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
2012-08-20 00:00:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:00:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\catalogs.php [ 8 ]
2012-08-20 00:00:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\catalogs.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\catalogs.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Catalogs->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Catalogs))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:00:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
2012-08-20 00:00:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:00:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\catalogs.php [ 8 ]
2012-08-20 00:00:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\catalogs.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\catalogs.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Catalogs->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Catalogs))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:04:52 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 18 ]
2012-08-20 00:04:52 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 18 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(18): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 18, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\app.php(10): Kohana_Response->body(Object(View))
#6 C:\wamp\www\frontend\application\classes\controller\admin\users.php(7): Controller_Admin_App->before()
#7 [internal function]: Controller_Admin_Users->before()
#8 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#9 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#12 {main}
2012-08-20 00:04:54 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 18 ]
2012-08-20 00:04:54 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 18 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(18): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 18, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\app.php(10): Kohana_Response->body(Object(View))
#6 C:\wamp\www\frontend\application\classes\controller\admin\users.php(7): Controller_Admin_App->before()
#7 [internal function]: Controller_Admin_Users->before()
#8 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#9 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#12 {main}
2012-08-20 00:04:54 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 18 ]
2012-08-20 00:04:54 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 18 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(18): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 18, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\app.php(10): Kohana_Response->body(Object(View))
#6 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(7): Controller_Admin_App->before()
#7 [internal function]: Controller_Admin_Pages->before()
#8 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#9 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#12 {main}
2012-08-20 00:05:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 18 ]
2012-08-20 00:05:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 18 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(18): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 18, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\app.php(10): Kohana_Response->body(Object(View))
#6 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(7): Controller_Admin_App->before()
#7 [internal function]: Controller_Admin_Pages->before()
#8 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#9 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#12 {main}
2012-08-20 00:05:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\users.php [ 8 ]
2012-08-20 00:05:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\users.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\users.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Users->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:06:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
2012-08-20 00:06:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:06:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\catalogs.php [ 8 ]
2012-08-20 00:06:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\catalogs.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\catalogs.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Catalogs->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Catalogs))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:10:19 --- ERROR: View_Exception [ 0 ]: The requested view template could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-08-20 00:10:19 --- STRACE: View_Exception [ 0 ]: The requested view template could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\view.php(137): Kohana_View->set_filename('template')
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(30): Kohana_View->__construct('template', NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(33): Kohana_View::factory('template')
#3 C:\wamp\www\frontend\application\classes\controller\admin\main.php(14): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-08-20 00:10:31 --- ERROR: View_Exception [ 0 ]: The requested view template could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-08-20 00:10:31 --- STRACE: View_Exception [ 0 ]: The requested view template could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\view.php(137): Kohana_View->set_filename('template')
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(30): Kohana_View->__construct('template', NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(33): Kohana_View::factory('template')
#3 C:\wamp\www\frontend\application\classes\controller\admin\main.php(14): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Admin_Main->before()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-08-20 00:12:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 7 ]
2012-08-20 00:12:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 7 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 7, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:19:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
2012-08-20 00:19:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Options->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:19:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
2012-08-20 00:19:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:20:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
2012-08-20 00:20:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Options->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:20:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\users.php [ 8 ]
2012-08-20 00:20:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\users.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\users.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Users->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:20:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
2012-08-20 00:20:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:20:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
2012-08-20 00:20:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Options->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:27:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
2012-08-20 00:27:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:28:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
2012-08-20 00:28:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:28:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
2012-08-20 00:28:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Options->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:32:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
2012-08-20 00:32:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\options.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\options.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Options->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:32:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
2012-08-20 00:32:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\classes\controller\admin\pages.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(8): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Admin_Pages->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:39:40 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:39:40 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:43:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/admin/auth was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 00:43:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/admin/auth was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-08-20 00:43:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/admin/auth was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 00:43:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/admin/auth was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-08-20 00:44:30 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:44:30 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:45:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/admin/auth was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 00:45:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/admin/auth was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-08-20 00:46:19 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:46:19 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 00:47:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/ad was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 00:47:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/ad was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-08-20 00:50:55 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/asdad was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 00:50:55 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/asdad was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-08-20 00:53:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/asdad was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 00:57:13 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/asdad was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 00:57:21 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:57:44 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:57:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/sdffs was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 00:58:38 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:59:12 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:59:19 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:59:23 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:59:25 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 00:59:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/wer was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 01:00:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/werwerw was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 01:00:41 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 01:02:30 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 01:02:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/asdad was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 01:02:51 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 01:05:06 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 01:05:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/asdad was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 01:05:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/asdadwr was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 01:07:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/asdadwr was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 01:07:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/page1 was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-08-20 01:07:48 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 01:07:52 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 01:08:12 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 01:08:55 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 01:08:55 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 01:09:09 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-20 01:09:09 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-20 01:24:43 --- ERROR: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\site\index.php [ 7 ]
2012-08-20 01:24:43 --- STRACE: ErrorException [ 8 ]: Undefined variable: options ~ APPPATH\views\site\index.php [ 7 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 7, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\page.php(71): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Page->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-20 01:26:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH\views\site\index.php [ 43 ]
2012-08-20 01:26:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH\views\site\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\home.php(70): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Home->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-20 01:28:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: profiler ~ APPPATH\views\site\index.php [ 49 ]
2012-08-20 01:28:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: profiler ~ APPPATH\views\site\index.php [ 49 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(49): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 49, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\page.php(80): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Page->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-20 01:30:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH\views\site\index.php [ 43 ]
2012-08-20 01:30:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH\views\site\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\home.php(70): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Home->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-20 01:43:46 --- ERROR: ErrorException [ 8 ]: Undefined variable: author ~ APPPATH\views\site\blocks\V_page.php [ 11 ]
2012-08-20 01:43:46 --- STRACE: ErrorException [ 8 ]: Undefined variable: author ~ APPPATH\views\site\blocks\V_page.php [ 11 ]
--
#0 C:\wamp\www\frontend\application\views\site\blocks\V_page.php(11): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 11, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\application\views\site\index.php(43): Kohana_View->__toString()
#5 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#6 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#7 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#8 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#9 C:\wamp\www\frontend\application\classes\controller\site\page.php(83): Kohana_Response->body(Object(View))
#10 [internal function]: Controller_Site_Page->action_index()
#11 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#12 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#14 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#15 {main}
2012-08-20 02:00:57 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH\views\site\index.php [ 43 ]
2012-08-20 02:00:57 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH\views\site\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\page.php(84): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Page->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}