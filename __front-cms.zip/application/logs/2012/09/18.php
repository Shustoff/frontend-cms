<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-09-18 10:52:04 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-18 10:52:04 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-18 16:25:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages/upload was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-09-18 16:25:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/pages/upload was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#3 {main}
2012-09-18 16:26:27 --- ERROR: ErrorException [ 2 ]: move_uploaded_file(assets/site/bigscream.jpg) [function.move-uploaded-file]: failed to open stream: Нет такого файла или каталога ~ APPPATH/classes/controller/admin/pages.php [ 104 ]
2012-09-18 16:26:27 --- STRACE: ErrorException [ 2 ]: move_uploaded_file(assets/site/bigscream.jpg) [function.move-uploaded-file]: failed to open stream: Нет такого файла или каталога ~ APPPATH/classes/controller/admin/pages.php [ 104 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'move_uploaded_f...', '/home/shustoff/...', 104, Array)
#1 /home/shustoff/music.shustoff.su/application/classes/controller/admin/pages.php(104): move_uploaded_file('/tmp/phpBpS0fZ', 'assets/site/big...')
#2 [internal function]: Controller_Admin_Pages->action_upload()
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-18 16:27:37 --- ERROR: ErrorException [ 2 ]: move_uploaded_file(assets/site/big/scream.jpg) [function.move-uploaded-file]: failed to open stream: Нет такого файла или каталога ~ APPPATH/classes/controller/admin/pages.php [ 104 ]
2012-09-18 16:27:37 --- STRACE: ErrorException [ 2 ]: move_uploaded_file(assets/site/big/scream.jpg) [function.move-uploaded-file]: failed to open stream: Нет такого файла или каталога ~ APPPATH/classes/controller/admin/pages.php [ 104 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'move_uploaded_f...', '/home/shustoff/...', 104, Array)
#1 /home/shustoff/music.shustoff.su/application/classes/controller/admin/pages.php(104): move_uploaded_file('/tmp/phpz8OiIN', 'assets/site/big...')
#2 [internal function]: Controller_Admin_Pages->action_upload()
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-18 16:30:21 --- ERROR: ErrorException [ 2 ]: move_uploaded_file(assets/site/img/big/smile.jpeg) [function.move-uploaded-file]: failed to open stream: Нет такого файла или каталога ~ APPPATH/classes/controller/admin/pages.php [ 104 ]
2012-09-18 16:30:21 --- STRACE: ErrorException [ 2 ]: move_uploaded_file(assets/site/img/big/smile.jpeg) [function.move-uploaded-file]: failed to open stream: Нет такого файла или каталога ~ APPPATH/classes/controller/admin/pages.php [ 104 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'move_uploaded_f...', '/home/shustoff/...', 104, Array)
#1 /home/shustoff/music.shustoff.su/application/classes/controller/admin/pages.php(104): move_uploaded_file('/tmp/phpTtBhKE', 'assets/site/img...')
#2 [internal function]: Controller_Admin_Pages->action_upload()
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#7 {main}