<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-08-26 19:12:21 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:12:28 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:13:38 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:16:27 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:18:04 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:18:25 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:19:55 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:21:03 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:21:15 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:22:36 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:22:37 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:22:37 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:22:38 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:22:38 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:24:04 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:24:04 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1261): Kohana_ORM->check(NULL)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1314): Kohana_ORM->update(NULL)
#2 C:\wamp\www\frontend\application\classes\controller\admin\app.php(52): Kohana_ORM->save()
#3 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('page')
#4 [internal function]: Controller_Admin_Pages->action_off()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-08-26 19:25:25 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:25:25 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1261): Kohana_ORM->check(NULL)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1314): Kohana_ORM->update(NULL)
#2 C:\wamp\www\frontend\application\classes\controller\admin\app.php(52): Kohana_ORM->save()
#3 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('page')
#4 [internal function]: Controller_Admin_Pages->action_off()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-08-26 19:25:30 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:25:30 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1261): Kohana_ORM->check(NULL)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1314): Kohana_ORM->update(NULL)
#2 C:\wamp\www\frontend\application\classes\controller\admin\app.php(52): Kohana_ORM->save()
#3 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('page')
#4 [internal function]: Controller_Admin_Pages->action_off()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-08-26 19:33:15 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM :'pages' WHERE id = :'1'' at line 1 [ UPDATE status FROM :'pages' WHERE id = :'1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:33:15 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM :'pages' WHERE id = :'1'' at line 1 [ UPDATE status FROM :'pages' WHERE id = :'1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE status F...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('pages')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:33:51 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM 'pages' WHERE id = '1'' at line 1 [ UPDATE status FROM 'pages' WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:33:51 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM 'pages' WHERE id = '1'' at line 1 [ UPDATE status FROM 'pages' WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE status F...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('pages')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:34:51 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM 'pages' WHERE id = '1'' at line 1 [ UPDATE status FROM 'pages' WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:34:51 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM 'pages' WHERE id = '1'' at line 1 [ UPDATE status FROM 'pages' WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE status F...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('pages')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:38:28 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"status" FROM 'pages' WHERE id = '1'' at line 1 [ UPDATE "status" FROM 'pages' WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:38:28 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"status" FROM 'pages' WHERE id = '1'' at line 1 [ UPDATE "status" FROM 'pages' WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE "status"...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('pages')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:40:03 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''pages' SET status = 0 WHERE id = '1'' at line 1 [ UPDATE 'pages' SET status = 0 WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:40:03 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''pages' SET status = 0 WHERE id = '1'' at line 1 [ UPDATE 'pages' SET status = 0 WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE 'pages' ...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('pages')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:42:27 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''pages' SET "status" = 0 WHERE "id" = '1'' at line 1 [ UPDATE 'pages' SET "status" = 0 WHERE "id" = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:42:27 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''pages' SET "status" = 0 WHERE "id" = '1'' at line 1 [ UPDATE 'pages' SET "status" = 0 WHERE "id" = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE 'pages' ...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('pages')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:45:45 --- ERROR: Database_Exception [ 1146 ]: Table 'frontend.'pages'' doesn't exist [ UPDATE `'pages'` SET `status`=0 WHERE `id`='1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:45:45 --- STRACE: Database_Exception [ 1146 ]: Table 'frontend.'pages'' doesn't exist [ UPDATE `'pages'` SET `status`=0 WHERE `id`='1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `'pages'...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('pages')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:46:33 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''pages' SET status=0 WHERE id='1'' at line 1 [ UPDATE 'pages' SET status=0 WHERE id='1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:46:33 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''pages' SET status=0 WHERE id='1'' at line 1 [ UPDATE 'pages' SET status=0 WHERE id='1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE 'pages' ...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('pages')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:49:22 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:49:22 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1261): Kohana_ORM->check(NULL)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(52): Kohana_ORM->update()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('page')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:51:18 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''page' SET status=0 WHERE id='1'' at line 1 [ UPDATE 'page' SET status=0 WHERE id='1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:51:18 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''page' SET status=0 WHERE id='1'' at line 1 [ UPDATE 'page' SET status=0 WHERE id='1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE 'page' S...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('page')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:51:19 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''page' SET status=0 WHERE id='2'' at line 1 [ UPDATE 'page' SET status=0 WHERE id='2' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:51:19 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''page' SET status=0 WHERE id='2'' at line 1 [ UPDATE 'page' SET status=0 WHERE id='2' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE 'page' S...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('page')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:51:20 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''page' SET status=0 WHERE id='3'' at line 1 [ UPDATE 'page' SET status=0 WHERE id='3' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:51:20 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''page' SET status=0 WHERE id='3'' at line 1 [ UPDATE 'page' SET status=0 WHERE id='3' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE 'page' S...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('page')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:52:04 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''page' SET status = "0" WHERE id = '1'' at line 1 [ UPDATE 'page' SET status = "0" WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:52:04 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''page' SET status = "0" WHERE id = '1'' at line 1 [ UPDATE 'page' SET status = "0" WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE 'page' S...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('page')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:52:32 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''pages' SET status = "0" WHERE id = '1'' at line 1 [ UPDATE 'pages' SET status = "0" WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:52:32 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''pages' SET status = "0" WHERE id = '1'' at line 1 [ UPDATE 'pages' SET status = "0" WHERE id = '1' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE 'pages' ...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(55): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(31): Controller_Admin_App->action_off('pages')
#3 [internal function]: Controller_Admin_Pages->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 19:54:23 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-08-26 19:54:23 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1261): Kohana_ORM->check(NULL)
#1 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1314): Kohana_ORM->update(NULL)
#2 C:\wamp\www\frontend\application\classes\controller\admin\app.php(46): Kohana_ORM->save()
#3 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(26): Controller_Admin_App->action_on('page')
#4 [internal function]: Controller_Admin_Pages->action_on()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-08-26 19:59:58 --- ERROR: Database_Exception [ 1146 ]: Table 'frontend.catalog' doesn't exist [ UPDATE `catalog` SET `status` = 0 WHERE `id` = '2' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 19:59:58 --- STRACE: Database_Exception [ 1146 ]: Table 'frontend.catalog' doesn't exist [ UPDATE `catalog` SET `status` = 0 WHERE `id` = '2' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `catalog...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(52): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\catalogs.php(31): Controller_Admin_App->action_off('catalog')
#3 [internal function]: Controller_Admin_Catalogs->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Catalogs))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-26 20:02:08 --- ERROR: Database_Exception [ 1146 ]: Table 'frontend.module' doesn't exist [ UPDATE `module` SET `status` = 0 WHERE `id` = '2' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
2012-08-26 20:02:08 --- STRACE: Database_Exception [ 1146 ]: Table 'frontend.module' doesn't exist [ UPDATE `module` SET `status` = 0 WHERE `id` = '2' ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `module`...', false, Array)
#1 C:\wamp\www\frontend\application\classes\controller\admin\app.php(52): Kohana_Database_Query->execute()
#2 C:\wamp\www\frontend\application\classes\controller\admin\modules.php(31): Controller_Admin_App->action_off('module')
#3 [internal function]: Controller_Admin_Modules->action_off()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}