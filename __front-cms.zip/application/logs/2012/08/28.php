<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-08-28 23:31:37 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 30 ]
2012-08-28 23:31:37 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 30 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-08-28 23:32:34 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 30 ]
2012-08-28 23:32:34 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 30 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}