<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-08-05 00:14:58 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\catalog.php [ 75 ]
2012-08-05 00:14:58 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\catalog.php [ 75 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\catalog.php(75): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 75, Array)
#1 [internal function]: Controller_Site_Catalog->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-05 00:57:46 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\site\blocks\V_catalog.php [ 3 ]
2012-08-05 00:57:46 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\site\blocks\V_catalog.php [ 3 ]
--
#0 C:\wamp\www\frontend\application\views\site\blocks\V_catalog.php(3): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 3, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\catalog.php(85): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Catalog->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-05 01:24:48 --- ERROR: View_Exception [ 0 ]: The requested view template could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
2012-08-05 01:24:48 --- STRACE: View_Exception [ 0 ]: The requested view template could not be found ~ SYSPATH\classes\kohana\view.php [ 252 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\view.php(137): Kohana_View->set_filename('template')
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(30): Kohana_View->__construct('template', NULL)
#2 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(33): Kohana_View::factory('template')
#3 [internal function]: Kohana_Controller_Template->before()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Main))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-05 01:30:38 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\main.php [ 28 ]
2012-08-05 01:30:38 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\main.php [ 28 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 01:38:41 --- ERROR: ErrorException [ 1 ]: Class 'Controller_Admin_App' not found ~ APPPATH\classes\controller\admin\options.php [ 3 ]
2012-08-05 01:38:41 --- STRACE: ErrorException [ 1 ]: Class 'Controller_Admin_App' not found ~ APPPATH\classes\controller\admin\options.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 01:40:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\main.php [ 28 ]
2012-08-05 01:40:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\main.php [ 28 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 01:44:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-08-05 01:44:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-08-05 01:44:51 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\home.php [ 28 ]
2012-08-05 01:44:51 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\home.php [ 28 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:10 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:10 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:14 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:14 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:16 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:16 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:17 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:17 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:18 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:18 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:21 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:21 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:22 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:22 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:22 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:22 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:22 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:22 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:22 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:22 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:22 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:22 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:22 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:22 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:22 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:22 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:22 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:22 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:22 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:22 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:23 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:23 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:23 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:23 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:23 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:23 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:23 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:23 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:23 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:23 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:23 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:23 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:23 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:23 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:23 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:23 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:24 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:24 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:24 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:24 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:24 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:24 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:24 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:24 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:24 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:24 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:24 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:24 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:24 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:24 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:24 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:24 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:26 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:26 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:36 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:36 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:36 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:36 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:36 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:36 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:36 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:36 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:36 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:36 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:36 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:36 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:37 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:37 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:37 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:37 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:37 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:37 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:37 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:37 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:37 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:37 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:37 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:37 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:38 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:38 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:38 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:38 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:38 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:38 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:38 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:38 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:38 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:38 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:38 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:38 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:38 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:38 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:39 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:39 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:39 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:39 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:39 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:39 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:39 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:39 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:39 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:39 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:39 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:39 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:40 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:40 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:40 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:40 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:40 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:40 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:40 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:40 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:40 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:40 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:40 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:40 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:40 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:40 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:41 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:41 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:41 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:41 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:41 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:41 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:41 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:41 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:41 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:41 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:41 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:41 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:42 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:42 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:42 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:42 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:42 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:42 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:42 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:42 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:42 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:42 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:42 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:42 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:43 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:43 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:43 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:43 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:43 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:43 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:43 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:43 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:43 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:43 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:44 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:44 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:44 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:44 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:44 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:44 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:44 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:44 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:44 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:44 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:45 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:45 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:45 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:45 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:45 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:45 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:45 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:45 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:45 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:45 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:46 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:46 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:46 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:46 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:46 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:46 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:46 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:46 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:46 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:46 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:46 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:46 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:48 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:48 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:48 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:48 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:48 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:48 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:48 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:48 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:48 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:48 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:49 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:49 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:49 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:49 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:49 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:49 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:49 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:49 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:49 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:49 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:50 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:50 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:50 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:50 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:50 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:50 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:50 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:50 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:50 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:50 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:51 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:51 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:51 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:51 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:51 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:51 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:51 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:51 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:52 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:52 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:52 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:52 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:52 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:52 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:52 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:52 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:52 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:52 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:53 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:53 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:53 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:53 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:53 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:53 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:53 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:53 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:54 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:54 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:54 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:54 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:54 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:54 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:54 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:54 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:55 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:55 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:55 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:55 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:55 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:55 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:55 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:55 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:00:55 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:00:55 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:03 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:03 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:03 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:03 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:04 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:04 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:04 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:04 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:04 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:04 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:04 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:04 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:07 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:07 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:01:08 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:01:08 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:13:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:13:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:13:31 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:13:31 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:13:33 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:13:33 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:13:37 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:13:37 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:16:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:16:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 05:16:48 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-05 05:16:48 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-05 17:44:12 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH\classes\controller\site\page.php [ 25 ]
2012-08-05 17:44:12 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH\classes\controller\site\page.php [ 25 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(25): Kohana_Core::error_handler(8, 'Undefined offse...', 'C:\wamp\www\fro...', 25, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}