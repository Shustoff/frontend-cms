<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-08-09 15:43:08 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' ~ APPPATH\classes\controller\site\home.php [ 57 ]
2012-08-09 15:43:08 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' ~ APPPATH\classes\controller\site\home.php [ 57 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 18:02:10 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ MODPATH\orm\classes\kohana\orm.php [ 37 ]
2012-08-09 18:02:10 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ MODPATH\orm\classes\kohana\orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 18:02:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\home.php [ 36 ]
2012-08-09 18:02:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\home.php [ 36 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 18:02:46 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\home.php [ 36 ]
2012-08-09 18:02:46 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\home.php [ 36 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 18:03:07 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\home.php [ 36 ]
2012-08-09 18:03:07 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\home.php [ 36 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 18:03:36 --- ERROR: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
2012-08-09 18:03:36 --- STRACE: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(32): Kohana_ORM->find_all()
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-09 18:03:43 --- ERROR: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
2012-08-09 18:03:43 --- STRACE: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(32): Kohana_ORM->find()
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-09 18:04:45 --- ERROR: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
2012-08-09 18:04:45 --- STRACE: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(32): Kohana_ORM->find()
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-09 22:51:45 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:51:45 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:54:09 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:54:09 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:54:25 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:54:25 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:54:41 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:54:41 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:54:42 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:54:42 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:54:46 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:54:46 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:54:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:54:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:55:11 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:55:11 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:55:13 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:55:13 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:56:44 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:56:44 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:58:04 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:58:04 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:58:15 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:58:15 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:58:19 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:58:19 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:58:29 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:58:29 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:58:31 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:58:31 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:58:58 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:58:58 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:58:59 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:58:59 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:59:29 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:59:29 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:59:41 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:59:41 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:59:43 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:59:43 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:59:45 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:59:45 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:59:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:59:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 22:59:50 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 22:59:50 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:00:31 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:00:31 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:00:32 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:00:32 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:01:37 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:01:37 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:01:40 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:01:40 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:01:56 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:01:56 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:02:05 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:02:05 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:32:56 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:32:56 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:35:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:35:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:37:54 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:37:54 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:38:12 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:38:12 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:39:45 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:39:45 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:40:47 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:40:47 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:40:54 --- ERROR: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
2012-08-09 23:40:54 --- STRACE: ErrorException [ 1 ]: Call to undefined function json_encode_cyr() ~ APPPATH\classes\controller\site\catalog.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-09 23:57:20 --- ERROR: Kohana_Exception [ 0 ]: The author property does not exist in the Model_Page class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
2012-08-09 23:57:20 --- STRACE: Kohana_Exception [ 0 ]: The author property does not exist in the Model_Page class ~ MODPATH\orm\classes\kohana\orm.php [ 612 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(31): Kohana_ORM->__get('author')
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}