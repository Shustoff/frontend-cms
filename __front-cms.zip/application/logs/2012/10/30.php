<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-10-30 20:16:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}
2012-10-30 20:16:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}
2012-10-30 20:16:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}
2012-10-30 20:16:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}
2012-10-30 20:16:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}
2012-10-30 20:16:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}
2012-10-30 20:16:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}
2012-10-30 20:16:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}
2012-10-30 20:16:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}
2012-10-30 20:16:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
2012-10-30 20:16:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/modules/checksysdname was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 113 ]
--
#0 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\music.shustoff.su\index.php(109): Kohana_Request->execute()
#3 {main}