<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-09-21 02:00:11 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-21 02:00:11 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-21 16:27:20 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '* FROM pages WHERE intrash = 1' at line 1 [ DELETE * FROM pages WHERE intrash = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-09-21 16:27:20 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '* FROM pages WHERE intrash = 1' at line 1 [ DELETE * FROM pages WHERE intrash = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(4, 'DELETE * FROM p...', false, Array)
#1 /home/shustoff/music.shustoff.su/application/classes/controller/admin/trash.php(83): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Admin_Trash->action_deleteall()
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-21 16:27:37 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '* FROM pages WHERE intrash = 1' at line 1 [ DELETE * FROM pages WHERE intrash = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-09-21 16:27:37 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '* FROM pages WHERE intrash = 1' at line 1 [ DELETE * FROM pages WHERE intrash = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(4, 'DELETE * FROM p...', false, Array)
#1 /home/shustoff/music.shustoff.su/application/classes/controller/admin/trash.php(83): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Admin_Trash->action_deleteall()
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#7 {main}
2012-09-21 16:30:22 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '* FROM `pages` WHERE `intrash` = 1' at line 1 [ DELETE * FROM `pages` WHERE `intrash` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-09-21 16:30:22 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '* FROM `pages` WHERE `intrash` = 1' at line 1 [ DELETE * FROM `pages` WHERE `intrash` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/shustoff/music.shustoff.su/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(4, 'DELETE * FROM `...', false, Array)
#1 /home/shustoff/music.shustoff.su/application/classes/controller/admin/trash.php(83): Kohana_Database_Query->execute()
#2 [internal function]: Controller_Admin_Trash->action_deleteall()
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#7 {main}