<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-05-21 23:43:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL front-end was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-21 23:43:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL front-end was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-21 23:43:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/index.php ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:43:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: front-end/index.php ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:54:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:54:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:57:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:57:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addcatalog.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addpage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/adduser.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/help.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-21 23:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-21 23:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/addimage.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}