<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-06-03 16:38:07 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:38:07 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:38:12 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:38:12 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:38:12 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:38:12 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:38:14 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:38:14 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:38:42 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:38:42 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:39:25 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:39:25 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:40:23 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:40:23 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:16 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:16 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:18 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:18 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:19 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:19 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:35 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:35 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:36 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:36 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:37 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:37 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:38 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:38 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:39 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:39 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:40 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:40 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:41:40 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:41:40 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:43:22 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:43:22 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:43:26 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:43:26 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:43:27 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:43:27 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:43:28 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:43:28 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:43:30 --- ERROR: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
2012-06-03 16:43:30 --- STRACE: ErrorException [ 1 ]: Class 'Model_Options' not found ~ SYSPATH\classes\kohana\model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 16:46:50 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 16:46:50 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 16:46:53 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 16:46:53 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 16:46:54 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 16:46:54 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 16:46:54 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 16:46:54 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 16:46:54 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 16:46:54 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 16:46:55 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 16:46:55 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 16:46:56 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 16:46:56 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 16:54:53 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 16:54:53 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 17:41:50 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 17:41:50 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 17:41:59 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 17:41:59 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 18:39:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admi was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-06-03 18:39:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admi was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-06-03 19:15:27 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 19:15:27 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:15:29 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 19:15:29 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:21:37 --- ERROR: ErrorException [ 8 ]: Undefined index: auth ~ APPPATH\classes\controller\admin\auth.php [ 16 ]
2012-06-03 19:21:37 --- STRACE: ErrorException [ 8 ]: Undefined index: auth ~ APPPATH\classes\controller\admin\auth.php [ 16 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(16): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 16, Array)
#1 [internal function]: Controller_Admin_Auth->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-03 19:21:45 --- ERROR: ErrorException [ 8 ]: Undefined index: auth ~ APPPATH\classes\controller\admin\auth.php [ 16 ]
2012-06-03 19:21:45 --- STRACE: ErrorException [ 8 ]: Undefined index: auth ~ APPPATH\classes\controller\admin\auth.php [ 16 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(16): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 16, Array)
#1 [internal function]: Controller_Admin_Auth->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-03 19:29:29 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH\classes\controller\admin\auth.php [ 28 ]
2012-06-03 19:29:29 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH\classes\controller\admin\auth.php [ 28 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:30:31 --- ERROR: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:30:31 --- STRACE: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(31): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:30:58 --- ERROR: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:30:58 --- STRACE: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(31): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:30:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:30:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(31): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:31:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:31:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(31): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:32:09 --- ERROR: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:32:09 --- STRACE: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(32): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:32:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:32:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: failpass ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(33): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:33:06 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
2012-06-03 19:33:06 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:33:07 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
2012-06-03 19:33:07 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:33:20 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
2012-06-03 19:33:20 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:33:21 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
2012-06-03 19:33:21 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:33:41 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
2012-06-03 19:33:41 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:33:48 --- ERROR: ErrorException [ 8 ]: Undefined variable: view ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
2012-06-03 19:33:48 --- STRACE: ErrorException [ 8 ]: Undefined variable: view ~ APPPATH\classes\controller\admin\auth.php [ 32 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(32): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 32, Array)
#1 [internal function]: Controller_Admin_Auth->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-03 19:38:37 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:38:37 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(30): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:38:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:38:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(30): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:43:08 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:43:08 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(31): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:43:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:43:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(31): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:43:55 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:43:55 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(31): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:43:58 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:43:58 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(31): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:44:58 --- ERROR: ErrorException [ 8 ]: Undefined variable: view ~ APPPATH\classes\controller\admin\auth.php [ 29 ]
2012-06-03 19:44:58 --- STRACE: ErrorException [ 8 ]: Undefined variable: view ~ APPPATH\classes\controller\admin\auth.php [ 29 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(29): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 29, Array)
#1 [internal function]: Controller_Admin_Auth->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-03 19:44:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: view ~ APPPATH\classes\controller\admin\auth.php [ 29 ]
2012-06-03 19:44:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: view ~ APPPATH\classes\controller\admin\auth.php [ 29 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(29): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 29, Array)
#1 [internal function]: Controller_Admin_Auth->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-03 19:46:12 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 15 ]
2012-06-03 19:46:12 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 15 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:46:13 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 15 ]
2012-06-03 19:46:13 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 15 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:48:00 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 8 ]
2012-06-03 19:48:00 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:48:01 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 8 ]
2012-06-03 19:48:01 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:48:01 --- ERROR: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 8 ]
2012-06-03 19:48:01 --- STRACE: ErrorException [ 1 ]: Cannot pass parameter 2 by reference ~ APPPATH\classes\controller\admin\auth.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 19:48:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:48:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(30): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:50:37 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:50:37 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(30): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 19:50:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
2012-06-03 19:50:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: faillogin ~ APPPATH\views\admin\login.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\login.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(30): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 20:01:05 --- ERROR: ErrorException [ 8 ]: Undefined index: auth ~ APPPATH\classes\controller\admin\auth.php [ 14 ]
2012-06-03 20:01:05 --- STRACE: ErrorException [ 8 ]: Undefined index: auth ~ APPPATH\classes\controller\admin\auth.php [ 14 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 14, Array)
#1 [internal function]: Controller_Admin_Auth->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-03 20:07:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admi/auth was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-06-03 20:07:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admi/auth was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-06-03 20:21:05 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 20:21:05 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 20:22:21 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 20:22:21 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 20:35:03 --- ERROR: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH\classes\controller\admin\main.php [ 18 ]
2012-06-03 20:35:03 --- STRACE: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH\classes\controller\admin\main.php [ 18 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\main.php(18): Kohana_Core::error_handler(2, 'Attempt to assi...', 'C:\wamp\www\fro...', 18, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-03 20:36:42 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 20:36:42 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 20:36:47 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 20:36:47 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 20:37:40 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admi was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-06-03 20:37:40 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admi was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-06-03 20:41:42 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 20:41:42 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 20:54:01 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend/admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-06-03 20:54:01 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend/admin/options was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-06-03 20:54:12 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 20:54:12 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 20:55:19 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 20:55:19 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 21:54:08 --- ERROR: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
2012-06-03 21:54:08 --- STRACE: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 21:55:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
2012-06-03 21:55:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 21:55:12 --- ERROR: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
2012-06-03 21:55:12 --- STRACE: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 21:55:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-06-03 21:55:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#1 {main}
2012-06-03 21:55:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-06-03 21:55:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/js/user.js ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#1 {main}
2012-06-03 21:55:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
2012-06-03 21:55:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 21:55:24 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/logout was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-06-03 21:55:24 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/logout was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#3 {main}
2012-06-03 21:55:35 --- ERROR: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
2012-06-03 21:55:35 --- STRACE: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 21:56:35 --- ERROR: ErrorException [ 8 ]: Undefined index: email ~ APPPATH\views\admin\index.php [ 43 ]
2012-06-03 21:56:35 --- STRACE: ErrorException [ 8 ]: Undefined index: email ~ APPPATH\views\admin\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(43): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 21:56:36 --- ERROR: ErrorException [ 8 ]: Undefined index: email ~ APPPATH\views\admin\index.php [ 43 ]
2012-06-03 21:56:36 --- STRACE: ErrorException [ 8 ]: Undefined index: email ~ APPPATH\views\admin\index.php [ 43 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(43): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 43, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 21:59:24 --- ERROR: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 19 ]
2012-06-03 21:59:24 --- STRACE: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 22:02:49 --- ERROR: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 19 ]
2012-06-03 22:02:49 --- STRACE: ErrorException [ 8 ]: Undefined variable: email ~ APPPATH\views\admin\index.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 22:13:23 --- ERROR: ErrorException [ 2048 ]: Non-static method Kohana_Auth::get_user() should not be called statically ~ APPPATH\views\admin\index.php [ 19 ]
2012-06-03 22:13:23 --- STRACE: ErrorException [ 2048 ]: Non-static method Kohana_Auth::get_user() should not be called statically ~ APPPATH\views\admin\index.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Core::error_handler(2048, 'Non-static meth...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Auth::get_user()
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#4 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#5 [internal function]: Kohana_Controller_Template->after()
#6 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#7 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#10 {main}
2012-06-03 22:14:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
2012-06-03 22:14:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 22:15:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
2012-06-03 22:15:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 22:15:22 --- ERROR: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
2012-06-03 22:15:22 --- STRACE: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 22:15:23 --- ERROR: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
2012-06-03 22:15:23 --- STRACE: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 22:15:28 --- ERROR: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
2012-06-03 22:15:28 --- STRACE: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 22:15:45 --- ERROR: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
2012-06-03 22:15:45 --- STRACE: ErrorException [ 8 ]: Undefined variable: usermail ~ APPPATH\views\admin\index.php [ 19 ]
--
#0 C:\wamp\www\frontend\application\views\admin\index.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 19, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\controller\template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#6 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#9 {main}
2012-06-03 22:17:04 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH\classes\controller\admin\main.php [ 24 ]
2012-06-03 22:17:04 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH\classes\controller\admin\main.php [ 24 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-06-03 22:18:57 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:18:57 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:19:54 --- ERROR: ErrorException [ 2048 ]: Only variables should be passed by reference ~ APPPATH\classes\controller\admin\main.php [ 22 ]
2012-06-03 22:19:54 --- STRACE: ErrorException [ 2048 ]: Only variables should be passed by reference ~ APPPATH\classes\controller\admin\main.php [ 22 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\main.php(22): Kohana_Core::error_handler(2048, 'Only variables ...', 'C:\wamp\www\fro...', 22, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-03 22:19:57 --- ERROR: ErrorException [ 2048 ]: Only variables should be passed by reference ~ APPPATH\classes\controller\admin\main.php [ 22 ]
2012-06-03 22:19:57 --- STRACE: ErrorException [ 2048 ]: Only variables should be passed by reference ~ APPPATH\classes\controller\admin\main.php [ 22 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\main.php(22): Kohana_Core::error_handler(2048, 'Only variables ...', 'C:\wamp\www\fro...', 22, Array)
#1 [internal function]: Controller_Admin_Main->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Main))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-06-03 22:36:23 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:36:23 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:37:23 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:37:23 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:37:27 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:37:27 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:37:51 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:37:51 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:38:16 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:38:16 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:39:20 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:39:20 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:39:49 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:39:49 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:39:51 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:39:51 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:39:59 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:39:59 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:41:59 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:41:59 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:54:12 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:54:12 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:54:12 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:54:12 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:54:12 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:54:12 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:54:12 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:54:12 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:54:13 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:54:13 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:54:39 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:54:39 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:54:40 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:54:40 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:54:40 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:54:40 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-06-03 22:54:40 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
2012-06-03 22:54:40 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\admin\blocks\V_options.php [ 4 ]
--
#0 C:\wamp\www\frontend\application\views\admin\blocks\V_options.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\wamp\www\fro...', 4, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\admin\options.php(23): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Options->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Options))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}