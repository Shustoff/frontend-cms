<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-11-01 00:17:00 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH\classes\kohana\cookie.php [ 152 ] in C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php:67
2012-11-01 00:17:00 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php(67): Kohana_Cookie::salt('session_name', NULL)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(155): Kohana_Cookie::get('session_name')
#2 C:\wamp\www\music.shustoff.su\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php:67
2012-11-01 00:23:33 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH\classes\kohana\cookie.php [ 152 ] in C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php:67
2012-11-01 00:23:33 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php(67): Kohana_Cookie::salt('session_name', NULL)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(155): Kohana_Cookie::get('session_name')
#2 C:\wamp\www\music.shustoff.su\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php:67
2012-11-01 00:23:34 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH\classes\kohana\cookie.php [ 152 ] in C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php:67
2012-11-01 00:23:34 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php(67): Kohana_Cookie::salt('session_name', NULL)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(155): Kohana_Cookie::get('session_name')
#2 C:\wamp\www\music.shustoff.su\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php:67
2012-11-01 00:23:34 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH\classes\kohana\cookie.php [ 152 ] in C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php:67
2012-11-01 00:23:34 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php(67): Kohana_Cookie::salt('session_name', NULL)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(155): Kohana_Cookie::get('session_name')
#2 C:\wamp\www\music.shustoff.su\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\wamp\www\music.shustoff.su\system\classes\kohana\cookie.php:67
2012-11-01 00:26:37 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\Controller\Admin\Auth.php [ 45 ] in :
2012-11-01 00:26:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 00:28:27 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\Controller\Admin\Main.php [ 12 ] in :
2012-11-01 00:28:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 00:28:44 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\Controller\Admin\Main.php [ 12 ] in :
2012-11-01 00:28:44 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 00:36:20 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:36:20 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfdsf', '<p>???sdfsdf</p...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfdsf', '<p>???sdfsdf</p...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfdsf', '<p>??sdfsdf</p>...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:38:23 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:38:23 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???awaea</p>...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???awaea</p>...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??awaea</p>?', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:38:27 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:38:27 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???awaeadawd...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???awaeadawd...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??awaeadawdd...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:38:29 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:38:29 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???awaeadawd...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???awaeadawd...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??awaeadawdd...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:38:33 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:38:33 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???awaeadawd...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???awaeadawd...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??awaeadawdd...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:40:05 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:40:05 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'asdasd', '<p>???awdaw</p>...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'asdasd', '<p>???awdaw</p>...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'asdasd', '<p>??awdaw</p>?', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:41:33 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:41:33 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'asdsad', '<p>???asdad</p>...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'asdsad', '<p>???asdad</p>...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'asdsad', '<p>??asdad</p>?', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:41:41 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:41:41 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'asdsad', '<p>???asdadasda...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'asdsad', '<p>???asdadasda...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'asdsad', '<p>??asdadasdas...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:41:42 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:41:42 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'asdsad', '<p>???asdadasda...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'asdsad', '<p>???asdadasda...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'asdsad', '<p>??asdadasdas...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:41:50 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:41:50 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'asdsad', '<p>???asdadasda...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'asdsad', '<p>???asdadasda...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'asdsad', '<p>??asdadasdas...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:42:33 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:42:33 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???sdfdsf</p...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???sdfdsf</p...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??sdfdsf</p>...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:42:55 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:42:55 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdfd', '<p>???sdfdsfdsf...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdfd', '<p>???sdfdsfdsf...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdfd', '<p>??sdfdsfdsfs...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:43:01 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:43:01 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdfdsdf sdf ...', '<p>???sdfdsfdsf...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdfdsdf sdf ...', '<p>???sdfdsfdsf...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdfdsdf sdf ...', '<p>??sdfdsfdsfs...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:43:44 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:43:44 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???sdfsf</p>...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???sdfsf</p>...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??sdfsf</p>?', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:43:50 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:43:50 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???sdfsfsdfs...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???sdfsfsdfs...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??sdfsfsdfsd...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:43:53 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:43:53 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???sdfsfsdfs...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???sdfsfsdfs...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??sdfsfsdfsd...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:44:13 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:44:13 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???sdfsfsdfs...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???sdfsfsdfs...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??sdfsfsdfsd...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 00:44:51 --- CRITICAL: ErrorException [ 2 ]: mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ] in :
2012-11-01 00:44:51 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'mail(): Failed ...', 'C:\wamp\www\mus...', 50, Array)
#1 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('manager@example...', 'sdfsdf', '<p>???sdfsdf</p...', 'Message-ID: <13...', '')
#2 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('manager@example...', 'sdfsdf', '<p>???sdfsdf</p...', 'Message-ID: <13...', '')
#3 C:\wamp\www\music.shustoff.su\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\music.shustoff.su\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Email.php(59): Email::send('manager@example...', 'dima.shustoff@g...', 'sdfsdf', '<p>??sdfsdf</p>...', true)
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Email->action_send()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in :
2012-11-01 01:13:18 --- CRITICAL: ErrorException [ 2 ]: SimpleXMLElement::addChild(): unterminated entity reference  Roger Shah feat. Amanda Angelic&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Альбом: &lt;/strong&gt;Hold On&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Год выпуска: &lt;/strong&gt;2010&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Продолжительность: &lt;/strong&gt;08:29&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Битрейт: &lt;/strong&gt;256 кб/с&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Размер: &lt;/strong&gt;15,5 МБ&lt;/p&gt; ~ SYSPATH\classes\kohana\feed.php [ 161 ] in :
2012-11-01 01:13:18 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'SimpleXMLElemen...', 'C:\wamp\www\mus...', 161, Array)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\feed.php(161): SimpleXMLElement->addChild('description', '<p><strong>????...')
#2 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Rss.php(23): Kohana_Feed::create(Array, Array)
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Rss->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Rss))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#9 {main} in :
2012-11-01 11:58:48 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'user_id' in 'order clause' [ SELECT `module`.`id` AS `id`, `module`.`name` AS `name`, `module`.`systemname` AS `systemname`, `module`.`content` AS `content`, `module`.`author_id` AS `author_id`, `module`.`type` AS `type`, `module`.`date` AS `date`, `module`.`status` AS `status`, `module`.`intrash` AS `intrash` FROM `modules` AS `module` WHERE `intrash` = '0' ORDER BY `user_id` LIMIT 5 OFFSET 0 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 11:58:48 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `module`...', 'Model_Module', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Modules.php(21): Controller_Admin_App->action_main('module')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Modules->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 11:59:10 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'user_id' in 'order clause' [ SELECT `module`.`id` AS `id`, `module`.`name` AS `name`, `module`.`systemname` AS `systemname`, `module`.`content` AS `content`, `module`.`author_id` AS `author_id`, `module`.`type` AS `type`, `module`.`date` AS `date`, `module`.`status` AS `status`, `module`.`intrash` AS `intrash` FROM `modules` AS `module` WHERE `intrash` = '0' ORDER BY `user_id` LIMIT 5 OFFSET 0 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 11:59:10 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `module`...', 'Model_Module', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Modules.php(21): Controller_Admin_App->action_main('module')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Modules->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Modules))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 12:22:58 --- CRITICAL: ErrorException [ 8 ]: Undefined index: idpage ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:22:58 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:23:16 --- CRITICAL: ErrorException [ 8 ]: Undefined index: idpage ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:23:16 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:23:18 --- CRITICAL: ErrorException [ 8 ]: Undefined index: idpage ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:23:18 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:24:27 --- CRITICAL: ErrorException [ 8 ]: Undefined index: idpage ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:24:27 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:28:43 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:28:43 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:34:54 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:34:54 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:35:54 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:35:54 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:35:55 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:35:55 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:08 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:43:08 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:43:10 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:10 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:11 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:11 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:27 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:43:27 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:43:28 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:28 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:31 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:31 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:32 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:32 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:45 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:45 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:46 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:43:46 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:05 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:05 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:07 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:07 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:08 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:08 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:10 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:10 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:10 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:10 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:11 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:11 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:11 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:11 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:12 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:12 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:12 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:44:12 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:44:14 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:14 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:15 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:44:15 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:19 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:45:19 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:45:20 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:20 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:21 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:21 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:22 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:22 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:23 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:23 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:24 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:24 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:36 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:36 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:36 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:45:36 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:45:38 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:45:38 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:45:38 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:38 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:45:39 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:45:39 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:45:40 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:45:40 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:47:08 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:47:08 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:47:09 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:09 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:10 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:10 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:10 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:10 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:11 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:11 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:12 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:12 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:13 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:47:13 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:10 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:10 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:11 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:11 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:11 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:11 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:18 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:18 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:18 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:18 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:19 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:48:19 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:48:19 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:48:19 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:48:47 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:48:47 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:48:48 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:48 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:49 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:48:49 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:48:51 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:51 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:48:52 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:48:52 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:49:10 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:49:10 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:49:10 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:49:10 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:49:11 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:49:11 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:49:45 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:49:45 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:49:45 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:49:45 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:50:24 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 47 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:50:24 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(47): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 47, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(26): Controller_Admin_App->action_on('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_on()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:47
2012-11-01 12:50:25 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:50:25 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:50:26 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:50:26 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:50:28 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:50:28 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:50:28 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Admin\App.php [ 53 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 12:50:28 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(53): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 53, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(31): Controller_Admin_App->action_off('pages')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_off()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php:53
2012-11-01 13:19:18 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Каталогу' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Каталогу` LIMIT 20 OFFSET 60 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:18 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:20 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Каталогу' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Каталогу` LIMIT 20 OFFSET 20 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:20 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:21 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Каталогу' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Каталогу` LIMIT 20 OFFSET 80 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:21 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:22 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Каталогу' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Каталогу` LIMIT 20 OFFSET 60 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:22 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:28 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Каталогу' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Каталогу` LIMIT 20 OFFSET 40 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:28 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:30 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Каталогу' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Каталогу` LIMIT 20 OFFSET 0 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:30 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:38 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Каталогу' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Каталогу` LIMIT 20 OFFSET 100 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:38 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:40 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Каталогу' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Каталогу` LIMIT 20 OFFSET 40 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:40 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:41 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Каталогу' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Каталогу` LIMIT 20 OFFSET 20 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:41 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:55 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Автору' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Автору` LIMIT 20 OFFSET 20 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:55 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:56 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Автору' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Автору` LIMIT 20 OFFSET 60 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:19:56 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:21:36 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Автору' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Автору` LIMIT 20 OFFSET 20 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:21:36 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:21:37 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Автору' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Автору` LIMIT 20 OFFSET 40 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:21:37 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:21:38 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Автору' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Автору` LIMIT 20 OFFSET 80 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:21:38 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:22:16 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Автору' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Автору` LIMIT 15 OFFSET 30 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:22:16 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:22:17 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Автору' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Автору` LIMIT 15 OFFSET 75 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:22:17 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:22:19 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Автору' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Автору` LIMIT 15 OFFSET 15 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:22:19 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:22:20 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'Автору' in 'order clause' [ SELECT `page`.`id` AS `id`, `page`.`pagename` AS `pagename`, `page`.`alias` AS `alias`, `page`.`metadesc` AS `metadesc`, `page`.`metakeywords` AS `metakeywords`, `page`.`content` AS `content`, `page`.`image` AS `image`, `page`.`catalog_id` AS `catalog_id`, `page`.`author_id` AS `author_id`, `page`.`date` AS `date`, `page`.`status` AS `status`, `page`.`intrash` AS `intrash`, `page`.`link` AS `link` FROM `pages` AS `page` WHERE `intrash` = '0' ORDER BY `Автору` LIMIT 15 OFFSET 90 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:22:20 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `page`.`...', 'Model_Page', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Pages.php(21): Controller_Admin_App->action_main('page')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Pages->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:34:36 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: page ~ APPPATH\views\admin\catalogs\V_catalogs.php [ 19 ] in C:\wamp\www\music.shustoff.su\application\views\admin\catalogs\V_catalogs.php:19
2012-11-01 13:34:36 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\views\admin\catalogs\V_catalogs.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\mus...', 19, Array)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\view.php(61): include('C:\wamp\www\mus...')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\view.php(348): Kohana_View::capture('C:\wamp\www\mus...', Array)
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(41): Kohana_Response->body(Object(View))
#6 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Catalogs.php(21): Controller_Admin_App->action_main('catalog')
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Catalogs->action_index()
#8 [internal function]: Kohana_Controller->execute()
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Catalogs))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#12 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#13 {main} in C:\wamp\www\music.shustoff.su\application\views\admin\catalogs\V_catalogs.php:19
2012-11-01 13:35:26 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'catdesc' in 'order clause' [ SELECT `catalog`.`id` AS `id`, `catalog`.`catname` AS `catname`, `catalog`.`alias` AS `alias`, `catalog`.`content` AS `content`, `catalog`.`parent_id` AS `parent_id`, `catalog`.`date` AS `date`, `catalog`.`status` AS `status`, `catalog`.`intrash` AS `intrash` FROM `catalogs` AS `catalog` WHERE `intrash` = '0' ORDER BY `catdesc` LIMIT 5 OFFSET 0 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 13:35:26 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `catalog...', 'Model_Catalog', Array)
#1 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1060): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 C:\wamp\www\music.shustoff.su\modules\orm\classes\kohana\orm.php(1001): Kohana_ORM->_load_result(true)
#3 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\App.php(29): Kohana_ORM->find_all()
#4 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Catalogs.php(21): Controller_Admin_App->action_main('catalog')
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Catalogs->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Catalogs))
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 14:05:40 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\Controller\Admin\Auth.php [ 9 ] in :
2012-11-01 14:05:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 14:53:28 --- CRITICAL: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH\views\admin\blocks\V_trash.php [ 33 ] in C:\wamp\www\music.shustoff.su\application\views\admin\blocks\V_trash.php:33
2012-11-01 14:53:28 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\views\admin\blocks\V_trash.php(33): Kohana_Core::error_handler(8, 'Trying to get p...', 'C:\wamp\www\mus...', 33, Array)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\view.php(61): include('C:\wamp\www\mus...')
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\view.php(348): Kohana_View::capture('C:\wamp\www\mus...', Array)
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(68): Kohana_Response->body(Object(View))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp\www\music.shustoff.su\application\views\admin\blocks\V_trash.php:33
2012-11-01 14:57:56 --- CRITICAL: ErrorException [ 8 ]: Undefined index: tablename ~ APPPATH\classes\Controller\Admin\Trash.php [ 78 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php:78
2012-11-01 14:57:56 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(78): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 78, Array)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_delete()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php:78
2012-11-01 14:57:57 --- CRITICAL: ErrorException [ 8 ]: Undefined index: tablename ~ APPPATH\classes\Controller\Admin\Trash.php [ 78 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php:78
2012-11-01 14:57:57 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(78): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 78, Array)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_delete()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php:78
2012-11-01 14:59:48 --- CRITICAL: ErrorException [ 8 ]: Undefined index: tablename ~ APPPATH\classes\Controller\Admin\Trash.php [ 73 ] in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php:73
2012-11-01 14:59:48 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(73): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\mus...', 73, Array)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_recovery()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php:73
2012-11-01 15:19:31 --- CRITICAL: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'SORT BY 'item_id' LIMIT 10 OFFSET 0' at line 14 [ SELECT id as item_id, pagename as item_name, date as item_date, status, intrash, "pages" tablename FROM pages
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, catname as item_name, date as item_date, status, intrash, "catalogs" FROM catalogs
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, email as item_name, datereg as item_date, status, intrash, "users" FROM users
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "roles" FROM roles
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "modules" FROM modules
                 WHERE intrash = 1 SORT BY 'item_id' LIMIT 10 OFFSET 0 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:19:31 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT id as it...', false, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(50): Kohana_Database_Query->execute()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:29:09 --- CRITICAL: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OFFSET 0 LIMIT 10' at line 14 [ SELECT id as item_id, pagename as item_name, date as item_date, status, intrash, "pages" tablename FROM pages
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, catname as item_name, date as item_date, status, intrash, "catalogs" FROM catalogs
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, email as item_name, datereg as item_date, status, intrash, "users" FROM users
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "roles" FROM roles
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "modules" FROM modules
                 WHERE intrash = 1 ORDER BY 'item_id' OFFSET 0 LIMIT 10 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:29:09 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT id as it...', false, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(50): Kohana_Database_Query->execute()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:29:48 --- CRITICAL: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OFFSET 0 LIMIT 10' at line 14 [ SELECT id as item_id, pagename as item_name, date as item_date, status, intrash, "pages" tablename FROM pages
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, catname as item_name, date as item_date, status, intrash, "catalogs" FROM catalogs
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, email as item_name, datereg as item_date, status, intrash, "users" FROM users
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "roles" FROM roles
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "modules" FROM modules
                 WHERE intrash = 1 ORDER BY 'item_id' OFFSET 0 LIMIT 10 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:29:48 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT id as it...', false, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(50): Kohana_Database_Query->execute()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:33:17 --- CRITICAL: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OFFSET 0 LIMIT 10' at line 14 [ SELECT id as item_id, pagename as item_name, date as item_date, status, intrash, "pages" tablename FROM pages
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, catname as item_name, date as item_date, status, intrash, "catalogs" FROM catalogs
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, email as item_name, datereg as item_date, status, intrash, "users" FROM users
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "roles" FROM roles
                 WHERE intrash = 1
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "modules" FROM modules
                 WHERE intrash = 1 ORDER BY 'item_id' OFFSET 0 LIMIT 10 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:33:17 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT id as it...', false, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(50): Kohana_Database_Query->execute()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:35:42 --- CRITICAL: Database_Exception [ 1221 ]: Incorrect usage of UNION and ORDER BY [ SELECT id as item_id, pagename as item_name, date as item_date, status, intrash, "pages" tablename FROM pages
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10
                    UNION ALL
                 SELECT id as item_id, catname as item_name, date as item_date, status, intrash, "catalogs" FROM catalogs
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10
                    UNION ALL
                 SELECT id as item_id, email as item_name, datereg as item_date, status, intrash, "users" FROM users
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "roles" FROM roles
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10
                    UNION ALL
                 SELECT id as item_id, name as item_name, date as item_date, status, intrash, "modules" FROM modules
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:35:42 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, 'SELECT id as it...', false, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(50): Kohana_Database_Query->execute()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:53:26 --- CRITICAL: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'UNION
                 (SELECT id as item_id, catname as item_name, date as ite' at line 3 [ (SELECT id as item_id, pagename as item_name, date as item_date, status, intrash, "pages" tablename FROM pages
                 WHERE intrash = 1) ORDER BY 'item_id' LIMIT 0, 10
                    UNION
                 (SELECT id as item_id, catname as item_name, date as item_date, status, intrash, "catalogs" FROM catalogs
                 WHERE intrash = 1) ORDER BY 'item_id' LIMIT 0, 10
                    UNION ALL
                 (SELECT id as item_id, email as item_name, datereg as item_date, status, intrash, "users" FROM users
                 WHERE intrash = 1) ORDER BY 'item_id' LIMIT 0, 10
                    UNION
                 (SELECT id as item_id, name as item_name, date as item_date, status, intrash, "roles" FROM roles
                 WHERE intrash = 1) ORDER BY 'item_id' LIMIT 0, 10
                    UNION
                 (SELECT id as item_id, name as item_name, date as item_date, status, intrash, "modules" FROM modules
                 WHERE intrash = 1)
                    ORDER BY 'item_id' LIMIT 0, 10 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:53:26 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, '(SELECT id as i...', false, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(51): Kohana_Database_Query->execute()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:53:51 --- CRITICAL: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'UNION
                 (SELECT id as item_id, catname as item_name, date as ite' at line 3 [ (SELECT id as item_id, pagename as item_name, date as item_date, status, intrash, "pages" tablename FROM pages
                 WHERE intrash = 1) LIMIT 0, 10
                    UNION
                 (SELECT id as item_id, catname as item_name, date as item_date, status, intrash, "catalogs" FROM catalogs
                 WHERE intrash = 1) LIMIT 0, 10
                    UNION ALL
                 (SELECT id as item_id, email as item_name, datereg as item_date, status, intrash, "users" FROM users
                 WHERE intrash = 1) LIMIT 0, 10
                    UNION
                 (SELECT id as item_id, name as item_name, date as item_date, status, intrash, "roles" FROM roles
                 WHERE intrash = 1) LIMIT 0, 10
                    UNION
                 (SELECT id as item_id, name as item_name, date as item_date, status, intrash, "modules" FROM modules
                 WHERE intrash = 1)
                    ORDER BY 'item_id' LIMIT 0, 10 ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:53:51 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, '(SELECT id as i...', false, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(51): Kohana_Database_Query->execute()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:59:29 --- CRITICAL: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 15 [ (SELECT id as item_id, pagename as item_name, date as item_date, status, intrash, "pages" tablename FROM pages
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10)
                    UNION ALL
                 (SELECT id as item_id, catname as item_name, date as item_date, status, intrash, "catalogs" FROM catalogs
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10)
                    UNION ALL
                 (SELECT id as item_id, email as item_name, datereg as item_date, status, intrash, "users" FROM users
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10)
                    UNION ALL
                 (SELECT id as item_id, name as item_name, date as item_date, status, intrash, "roles" FROM roles
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10)
                    UNION ALL
                 (SELECT id as item_id, name as item_name, date as item_date, status, intrash, "modules" FROM modules
                 WHERE intrash = 1 ORDER BY 'item_id' LIMIT 0, 10)
                     ORDER BY 'item_id' LIMIT 0, 10) ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 194 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 15:59:29 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(251): Kohana_Database_MySQL->query(1, '(SELECT id as i...', false, Array)
#1 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Trash.php(51): Kohana_Database_Query->execute()
#2 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Trash->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Trash))
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php:251
2012-11-01 16:47:04 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\Controller\Admin\Auth.php [ 9 ] in :
2012-11-01 16:47:04 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 16:47:06 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\Controller\Admin\Auth.php [ 9 ] in :
2012-11-01 16:47:06 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 17:32:13 --- CRITICAL: ErrorException [ 2 ]: SimpleXMLElement::addChild(): unterminated entity reference  Roger Shah feat. Amanda Angelic&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Альбом: &lt;/strong&gt;Hold On&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Год выпуска: &lt;/strong&gt;2010&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Продолжительность: &lt;/strong&gt;08:29&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Битрейт: &lt;/strong&gt;256 кб/с&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Размер: &lt;/strong&gt;15,5 МБ&lt;/p&gt; ~ SYSPATH\classes\kohana\feed.php [ 161 ] in :
2012-11-01 17:32:13 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'SimpleXMLElemen...', 'C:\wamp\www\mus...', 161, Array)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\feed.php(161): SimpleXMLElement->addChild('description', '<p><strong>????...')
#2 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Rss.php(23): Kohana_Feed::create(Array, Array)
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Rss->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Rss))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#9 {main} in :
2012-11-01 17:33:13 --- CRITICAL: ErrorException [ 2 ]: SimpleXMLElement::addChild(): unterminated entity reference  Re-Con&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Альбом: &lt;/strong&gt;Clubland X-treme Hardcore 3&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Год выпуска: &lt;/strong&gt;2006&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Продолжительность: &lt;/strong&gt;03:47&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Битрейт: &lt;/strong&gt;192 кб/с&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;Размер: &lt;/strong&gt;5,2 МБ&lt;/p&gt; ~ SYSPATH\classes\kohana\feed.php [ 161 ] in :
2012-11-01 17:33:13 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'SimpleXMLElemen...', 'C:\wamp\www\mus...', 161, Array)
#1 C:\wamp\www\music.shustoff.su\system\classes\kohana\feed.php(161): SimpleXMLElement->addChild('description', '<p><strong>????...')
#2 C:\wamp\www\music.shustoff.su\application\classes\Controller\Admin\Rss.php(23): Kohana_Feed::create(Array, Array)
#3 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(84): Controller_Admin_Rss->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Rss))
#6 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#9 {main} in :
2012-11-01 17:50:52 --- CRITICAL: Database_Exception [ 2 ]: mysql_connect(): Access denied for user 'shustoff_music'@'localhost' (using password: YES) ~ MODPATH\database\classes\kohana\database\mysql.php [ 67 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\mysql.php:430
2012-11-01 17:50:52 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\mysql.php(430): Kohana_Database_MySQL->connect()
#1 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database.php(478): Kohana_Database_MySQL->escape('site')
#2 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query\builder.php(116): Kohana_Database->quote('site')
#3 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query\builder\select.php(372): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL), Array)
#4 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\query.php(234): Kohana_Database_Query_Builder_Select->compile(Object(Database_MySQL))
#5 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\config\database\reader.php(62): Kohana_Database_Query->execute(Object(Database_MySQL))
#6 C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\config\database\writer.php(26): Kohana_Config_Database_Reader->load('site')
#7 C:\wamp\www\music.shustoff.su\system\classes\kohana\config.php(130): Kohana_Config_Database_Writer->load('site')
#8 C:\wamp\www\music.shustoff.su\application\classes\Controller\Site\Page.php(7): Kohana_Config->load('site.status')
#9 C:\wamp\www\music.shustoff.su\system\classes\kohana\controller.php(69): Controller_Site_Page->before()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client\internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Page))
#12 C:\wamp\www\music.shustoff.su\system\classes\kohana\request\client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\wamp\www\music.shustoff.su\system\classes\kohana\request.php(990): Kohana_Request_Client->execute(Object(Request))
#14 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#15 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\kohana\database\mysql.php:430
2012-11-01 18:14:12 --- CRITICAL: Database_Exception [ 2 ]: mysql_connect(): Access denied for user 'shustoff_music'@'localhost' (using password: YES) ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 67 ] in C:\wamp\www\music.shustoff.su\modules\database\classes\Kohana\Database\MySQL.php:430
2012-11-01 18:14:12 --- DEBUG: #0 C:\wamp\www\music.shustoff.su\modules\database\classes\Kohana\Database\MySQL.php(430): Kohana_Database_MySQL->connect()
#1 C:\wamp\www\music.shustoff.su\modules\database\classes\Kohana\Database.php(478): Kohana_Database_MySQL->escape('site')
#2 C:\wamp\www\music.shustoff.su\modules\database\classes\Kohana\Database\Query\Builder.php(116): Kohana_Database->quote('site')
#3 C:\wamp\www\music.shustoff.su\modules\database\classes\Kohana\Database\Query\Builder\Select.php(372): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL), Array)
#4 C:\wamp\www\music.shustoff.su\modules\database\classes\Kohana\Database\Query.php(234): Kohana_Database_Query_Builder_Select->compile(Object(Database_MySQL))
#5 C:\wamp\www\music.shustoff.su\modules\database\classes\Kohana\Config\Database\Reader.php(62): Kohana_Database_Query->execute(Object(Database_MySQL))
#6 C:\wamp\www\music.shustoff.su\modules\database\classes\Kohana\Config\Database\Writer.php(26): Kohana_Config_Database_Reader->load('site')
#7 C:\wamp\www\music.shustoff.su\system\classes\Kohana\Config.php(130): Kohana_Config_Database_Writer->load('site')
#8 C:\wamp\www\music.shustoff.su\application\classes\Controller\Site\Home.php(7): Kohana_Config->load('site.status')
#9 C:\wamp\www\music.shustoff.su\system\classes\Kohana\Controller.php(69): Controller_Site_Home->before()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\wamp\www\music.shustoff.su\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Home))
#12 C:\wamp\www\music.shustoff.su\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\wamp\www\music.shustoff.su\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#14 C:\wamp\www\music.shustoff.su\index.php(118): Kohana_Request->execute()
#15 {main} in C:\wamp\www\music.shustoff.su\modules\database\classes\Kohana\Database\MySQL.php:430
2012-11-01 18:21:27 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Mysql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:21:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:22:30 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Mysql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:22:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:22:31 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Mysql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:22:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:22:54 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Mysql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:22:54 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:23:18 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Mysql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:23:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:23:26 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Mysql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:23:26 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:23:38 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Mysql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:23:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:24:15 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Mysql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:24:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:24:35 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_MySql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:24:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:24:35 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_MySql' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in :
2012-11-01 18:24:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:24:50 --- EMERGENCY: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'shustoff_music'@'localhost' (using password: YES) ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/MySQL.php:430
2012-11-01 18:24:50 --- DEBUG: #0 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/MySQL.php(430): Kohana_Database_MySQL->connect()
#1 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database.php(478): Kohana_Database_MySQL->escape('site')
#2 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/Query/Builder.php(116): Kohana_Database->quote('site')
#3 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/Query/Builder/Select.php(372): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL), Array)
#4 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/Query.php(234): Kohana_Database_Query_Builder_Select->compile(Object(Database_MySQL))
#5 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Config/Database/Reader.php(62): Kohana_Database_Query->execute(Object(Database_MySQL))
#6 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Config/Database/Writer.php(26): Kohana_Config_Database_Reader->load('site')
#7 /home/shustoff/music.shustoff.su/system/classes/Kohana/Config.php(130): Kohana_Config_Database_Writer->load('site')
#8 /home/shustoff/music.shustoff.su/application/classes/Controller/Site/Home.php(7): Kohana_Config->load('site.status')
#9 /home/shustoff/music.shustoff.su/system/classes/Kohana/Controller.php(69): Controller_Site_Home->before()
#10 [internal function]: Kohana_Controller->execute()
#11 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Home))
#12 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request.php(990): Kohana_Request_Client->execute(Object(Request))
#14 /home/shustoff/music.shustoff.su/index.php(118): Kohana_Request->execute()
#15 {main} in /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/MySQL.php:430
2012-11-01 18:25:01 --- EMERGENCY: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'shustoff_music'@'localhost' (using password: YES) ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/MySQL.php:430
2012-11-01 18:25:01 --- DEBUG: #0 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/MySQL.php(430): Kohana_Database_MySQL->connect()
#1 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database.php(478): Kohana_Database_MySQL->escape('site')
#2 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/Query/Builder.php(116): Kohana_Database->quote('site')
#3 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/Query/Builder/Select.php(372): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL), Array)
#4 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/Query.php(234): Kohana_Database_Query_Builder_Select->compile(Object(Database_MySQL))
#5 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Config/Database/Reader.php(62): Kohana_Database_Query->execute(Object(Database_MySQL))
#6 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Config/Database/Writer.php(26): Kohana_Config_Database_Reader->load('site')
#7 /home/shustoff/music.shustoff.su/system/classes/Kohana/Config.php(130): Kohana_Config_Database_Writer->load('site')
#8 /home/shustoff/music.shustoff.su/application/classes/Controller/Site/Home.php(7): Kohana_Config->load('site.status')
#9 /home/shustoff/music.shustoff.su/system/classes/Kohana/Controller.php(69): Controller_Site_Home->before()
#10 [internal function]: Kohana_Controller->execute()
#11 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Home))
#12 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request.php(990): Kohana_Request_Client->execute(Object(Request))
#14 /home/shustoff/music.shustoff.su/index.php(118): Kohana_Request->execute()
#15 {main} in /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/MySQL.php:430
2012-11-01 18:25:30 --- EMERGENCY: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'shustoff_music'@'localhost' (using password: YES) ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/MySQL.php:430
2012-11-01 18:25:30 --- DEBUG: #0 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/MySQL.php(430): Kohana_Database_MySQL->connect()
#1 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database.php(478): Kohana_Database_MySQL->escape('site')
#2 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/Query/Builder.php(116): Kohana_Database->quote('site')
#3 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/Query/Builder/Select.php(372): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL), Array)
#4 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/Query.php(234): Kohana_Database_Query_Builder_Select->compile(Object(Database_MySQL))
#5 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Config/Database/Reader.php(62): Kohana_Database_Query->execute(Object(Database_MySQL))
#6 /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Config/Database/Writer.php(26): Kohana_Config_Database_Reader->load('site')
#7 /home/shustoff/music.shustoff.su/system/classes/Kohana/Config.php(130): Kohana_Config_Database_Writer->load('site')
#8 /home/shustoff/music.shustoff.su/application/classes/Controller/Site/Page.php(7): Kohana_Config->load('site.status')
#9 /home/shustoff/music.shustoff.su/system/classes/Kohana/Controller.php(69): Controller_Site_Page->before()
#10 [internal function]: Kohana_Controller->execute()
#11 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Site_Page))
#12 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request.php(990): Kohana_Request_Client->execute(Object(Request))
#14 /home/shustoff/music.shustoff.su/index.php(118): Kohana_Request->execute()
#15 {main} in /home/shustoff/music.shustoff.su/modules/database/classes/Kohana/Database/MySQL.php:430
2012-11-01 18:25:33 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:25:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:26:17 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:26:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:26:45 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:26:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:27:01 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:27:01 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:28:57 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:28:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:28:59 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:28:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:29:02 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:29:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:29:06 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:29:06 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:29:16 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:29:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:29:31 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:29:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:30:18 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:30:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:31:30 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:31:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:31:32 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:31:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:31:45 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:31:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:32:39 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:32:39 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:32:47 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:32:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:33:43 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:33:43 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:33:50 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:33:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:34:15 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:34:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:34:39 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:34:39 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:34:59 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:34:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:35:02 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:35:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:35:23 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_page' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:35:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:36:05 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_module' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:36:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:36:15 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_module' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:36:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:36:45 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_module' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:36:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:37:16 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_module' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:37:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:38:30 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_module' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:38:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:38:44 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_module' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:38:44 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:39:05 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_module' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:39:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:41:14 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:41:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:41:19 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:41:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:46:28 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:46:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:47:58 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:47:58 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:54:29 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:54:29 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:57:10 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:57:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:58:36 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:58:36 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 18:59:19 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 18:59:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 19:02:15 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 19:02:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 19:04:06 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 19:04:06 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 19:06:32 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_catalog' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in :
2012-11-01 19:06:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in :
2012-11-01 19:36:11 --- EMERGENCY: View_Exception [ 0 ]: The requested view admin/Pages/V_Pages could not be found ~ SYSPATH/classes/Kohana/View.php [ 257 ] in /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php:137
2012-11-01 19:36:11 --- DEBUG: #0 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(137): Kohana_View->set_filename('admin/Pages/V_P...')
#1 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(30): Kohana_View->__construct('admin/Pages/V_P...', NULL)
#2 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/App.php(36): Kohana_View::factory('admin/Pages/V_P...')
#3 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/Pages.php(21): Controller_Admin_App->action_main('Page')
#4 /home/shustoff/music.shustoff.su/system/classes/Kohana/Controller.php(84): Controller_Admin_Pages->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#7 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request.php(990): Kohana_Request_Client->execute(Object(Request))
#9 /home/shustoff/music.shustoff.su/index.php(118): Kohana_Request->execute()
#10 {main} in /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php:137
2012-11-01 19:42:26 --- EMERGENCY: View_Exception [ 0 ]: The requested view admin/Pages/V_Pages could not be found ~ SYSPATH/classes/Kohana/View.php [ 257 ] in /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php:137
2012-11-01 19:42:26 --- DEBUG: #0 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(137): Kohana_View->set_filename('admin/Pages/V_P...')
#1 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(30): Kohana_View->__construct('admin/Pages/V_P...', NULL)
#2 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/App.php(36): Kohana_View::factory('admin/Pages/V_P...')
#3 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/Pages.php(21): Controller_Admin_App->action_main('Page')
#4 /home/shustoff/music.shustoff.su/system/classes/Kohana/Controller.php(84): Controller_Admin_Pages->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#7 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request.php(990): Kohana_Request_Client->execute(Object(Request))
#9 /home/shustoff/music.shustoff.su/index.php(118): Kohana_Request->execute()
#10 {main} in /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php:137
2012-11-01 19:42:58 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH/views/admin/Pages/V_Pages.php [ 15 ] in /home/shustoff/music.shustoff.su/application/views/admin/Pages/V_Pages.php:15
2012-11-01 19:42:58 --- DEBUG: #0 /home/shustoff/music.shustoff.su/application/views/admin/Pages/V_Pages.php(15): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/shustoff/...', 15, Array)
#1 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(61): include('/home/shustoff/...')
#2 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(348): Kohana_View::capture('/home/shustoff/...', Array)
#3 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(228): Kohana_View->render()
#4 /home/shustoff/music.shustoff.su/system/classes/Kohana/Response.php(160): Kohana_View->__toString()
#5 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/App.php(41): Kohana_Response->body(Object(View))
#6 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/Pages.php(21): Controller_Admin_App->action_main('Page')
#7 /home/shustoff/music.shustoff.su/system/classes/Kohana/Controller.php(84): Controller_Admin_Pages->action_index()
#8 [internal function]: Kohana_Controller->execute()
#9 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#10 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request.php(990): Kohana_Request_Client->execute(Object(Request))
#12 /home/shustoff/music.shustoff.su/index.php(118): Kohana_Request->execute()
#13 {main} in /home/shustoff/music.shustoff.su/application/views/admin/Pages/V_Pages.php:15
2012-11-01 19:44:24 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH/views/admin/Pages/V_Pages.php [ 15 ] in /home/shustoff/music.shustoff.su/application/views/admin/Pages/V_Pages.php:15
2012-11-01 19:44:24 --- DEBUG: #0 /home/shustoff/music.shustoff.su/application/views/admin/Pages/V_Pages.php(15): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/shustoff/...', 15, Array)
#1 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(61): include('/home/shustoff/...')
#2 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(348): Kohana_View::capture('/home/shustoff/...', Array)
#3 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(228): Kohana_View->render()
#4 /home/shustoff/music.shustoff.su/system/classes/Kohana/Response.php(160): Kohana_View->__toString()
#5 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/App.php(41): Kohana_Response->body(Object(View))
#6 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/Pages.php(21): Controller_Admin_App->action_main('Page')
#7 /home/shustoff/music.shustoff.su/system/classes/Kohana/Controller.php(84): Controller_Admin_Pages->action_index()
#8 [internal function]: Kohana_Controller->execute()
#9 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#10 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request.php(990): Kohana_Request_Client->execute(Object(Request))
#12 /home/shustoff/music.shustoff.su/index.php(118): Kohana_Request->execute()
#13 {main} in /home/shustoff/music.shustoff.su/application/views/admin/Pages/V_Pages.php:15
2012-11-01 19:44:26 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH/views/admin/Pages/V_Pages.php [ 15 ] in /home/shustoff/music.shustoff.su/application/views/admin/Pages/V_Pages.php:15
2012-11-01 19:44:26 --- DEBUG: #0 /home/shustoff/music.shustoff.su/application/views/admin/Pages/V_Pages.php(15): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/shustoff/...', 15, Array)
#1 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(61): include('/home/shustoff/...')
#2 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(348): Kohana_View::capture('/home/shustoff/...', Array)
#3 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(228): Kohana_View->render()
#4 /home/shustoff/music.shustoff.su/system/classes/Kohana/Response.php(160): Kohana_View->__toString()
#5 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/App.php(41): Kohana_Response->body(Object(View))
#6 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/Pages.php(21): Controller_Admin_App->action_main('Page')
#7 /home/shustoff/music.shustoff.su/system/classes/Kohana/Controller.php(84): Controller_Admin_Pages->action_index()
#8 [internal function]: Kohana_Controller->execute()
#9 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#10 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request.php(990): Kohana_Request_Client->execute(Object(Request))
#12 /home/shustoff/music.shustoff.su/index.php(118): Kohana_Request->execute()
#13 {main} in /home/shustoff/music.shustoff.su/application/views/admin/Pages/V_Pages.php:15
2012-11-01 19:48:58 --- EMERGENCY: View_Exception [ 0 ]: The requested view admin/users/V_users could not be found ~ SYSPATH/classes/Kohana/View.php [ 257 ] in /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php:137
2012-11-01 19:48:58 --- DEBUG: #0 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(137): Kohana_View->set_filename('admin/users/V_u...')
#1 /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php(30): Kohana_View->__construct('admin/users/V_u...', NULL)
#2 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/App.php(38): Kohana_View::factory('admin/users/V_u...')
#3 /home/shustoff/music.shustoff.su/application/classes/Controller/Admin/Users.php(21): Controller_Admin_App->action_main('User')
#4 /home/shustoff/music.shustoff.su/system/classes/Kohana/Controller.php(84): Controller_Admin_Users->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#7 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/shustoff/music.shustoff.su/system/classes/Kohana/Request.php(990): Kohana_Request_Client->execute(Object(Request))
#9 /home/shustoff/music.shustoff.su/index.php(118): Kohana_Request->execute()
#10 {main} in /home/shustoff/music.shustoff.su/system/classes/Kohana/View.php:137