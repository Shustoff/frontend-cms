<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-09-19 00:31:06 --- ERROR: ErrorException [ 8 ]: Undefined index: userfile ~ APPPATH/classes/controller/admin/pages.php [ 102 ]
2012-09-19 00:31:06 --- STRACE: ErrorException [ 8 ]: Undefined index: userfile ~ APPPATH/classes/controller/admin/pages.php [ 102 ]
--
#0 /home/shustoff/music.shustoff.su/application/classes/controller/admin/pages.php(102): Kohana_Core::error_handler(8, 'Undefined index...', '/home/shustoff/...', 102, Array)
#1 [internal function]: Controller_Admin_Pages->action_upload()
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-19 00:32:25 --- ERROR: ErrorException [ 8 ]: Undefined index: userfile ~ APPPATH/classes/controller/admin/pages.php [ 102 ]
2012-09-19 00:32:25 --- STRACE: ErrorException [ 8 ]: Undefined index: userfile ~ APPPATH/classes/controller/admin/pages.php [ 102 ]
--
#0 /home/shustoff/music.shustoff.su/application/classes/controller/admin/pages.php(102): Kohana_Core::error_handler(8, 'Undefined index...', '/home/shustoff/...', 102, Array)
#1 [internal function]: Controller_Admin_Pages->action_upload()
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#6 {main}
2012-09-19 01:40:54 --- ERROR: Kohana_Exception [ 0 ]: Not an image or invalid image:  ~ MODPATH/image/classes/kohana/image.php [ 106 ]
2012-09-19 01:40:54 --- STRACE: Kohana_Exception [ 0 ]: Not an image or invalid image:  ~ MODPATH/image/classes/kohana/image.php [ 106 ]
--
#0 /home/shustoff/music.shustoff.su/modules/image/classes/kohana/image/gd.php(90): Kohana_Image->__construct('assets/img/site...')
#1 /home/shustoff/music.shustoff.su/modules/image/classes/kohana/image.php(53): Kohana_Image_GD->__construct('assets/img/site...')
#2 /home/shustoff/music.shustoff.su/application/classes/controller/admin/pages.php(103): Kohana_Image::factory('assets/img/site...')
#3 [internal function]: Controller_Admin_Pages->action_upload()
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#5 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#8 {main}
2012-09-19 02:20:12 --- ERROR: ErrorException [ 8 ]: Undefined variable: page ~ APPPATH/views/admin/pages/V_addpage.php [ 97 ]
2012-09-19 02:20:12 --- STRACE: ErrorException [ 8 ]: Undefined variable: page ~ APPPATH/views/admin/pages/V_addpage.php [ 97 ]
--
#0 /home/shustoff/music.shustoff.su/application/views/admin/pages/V_addpage.php(97): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/shustoff/...', 97, Array)
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/view.php(61): include('/home/shustoff/...')
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/view.php(343): Kohana_View::capture('/home/shustoff/...', Array)
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/response.php(160): Kohana_View->__toString()
#5 /home/shustoff/music.shustoff.su/application/classes/controller/admin/pages.php(53): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Pages->action_addpages()
#7 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-19 02:20:15 --- ERROR: ErrorException [ 8 ]: Undefined variable: page ~ APPPATH/views/admin/pages/V_addpage.php [ 97 ]
2012-09-19 02:20:15 --- STRACE: ErrorException [ 8 ]: Undefined variable: page ~ APPPATH/views/admin/pages/V_addpage.php [ 97 ]
--
#0 /home/shustoff/music.shustoff.su/application/views/admin/pages/V_addpage.php(97): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/shustoff/...', 97, Array)
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/view.php(61): include('/home/shustoff/...')
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/view.php(343): Kohana_View::capture('/home/shustoff/...', Array)
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /home/shustoff/music.shustoff.su/system/classes/kohana/response.php(160): Kohana_View->__toString()
#5 /home/shustoff/music.shustoff.su/application/classes/controller/admin/pages.php(53): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Admin_Pages->action_addpages()
#7 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#8 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#11 {main}