<div class="infoTable">
<?php phpinfo(); ?>
</div>