<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-05-23 23:03:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/addpage was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-23 23:03:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/addpage was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-23 23:04:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/addpage was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-23 23:04:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/addpage was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-23 23:04:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-23 23:04:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-23 23:04:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-icons_222222_256x240.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-23 23:04:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-icons_222222_256x240.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-23 23:08:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-icons_222222_256x240.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-23 23:08:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-icons_222222_256x240.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-23 23:08:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-23 23:08:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-23 23:10:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-23 23:10:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-23 23:10:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-icons_222222_256x240.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-05-23 23:10:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/css/images/ui-icons_222222_256x240.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-23 23:18:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/stats was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-23 23:18:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/stats was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-23 23:20:40 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/info was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2012-05-23 23:20:40 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/info was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 C:\wamp\www\front-end\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 C:\wamp\www\front-end\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 C:\wamp\www\front-end\index.php(109): Kohana_Request->execute()
#3 {main}