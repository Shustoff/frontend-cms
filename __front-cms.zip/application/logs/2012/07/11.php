<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-07-11 01:28:04 --- ERROR: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: YES) ~ MODPATH\database\classes\kohana\database\mysql.php [ 67 ]
2012-07-11 01:28:04 --- STRACE: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: YES) ~ MODPATH\database\classes\kohana\database\mysql.php [ 67 ]
--
#0 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql.php(171): Kohana_Database_MySQL->connect()
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql.php(360): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1504): Kohana_Database_MySQL->list_columns('users')
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(392): Kohana_ORM->list_columns(true)
#4 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(337): Kohana_ORM->reload_columns()
#5 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(246): Kohana_ORM->_initialize()
#6 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(37): Kohana_ORM->__construct(NULL)
#7 C:\wamp\www\frontend\modules\orm\classes\kohana\auth\orm.php(75): Kohana_ORM::factory('user')
#8 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(90): Kohana_Auth_ORM->_login('admin', 'admin123', false)
#9 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth->login('admin', 'admin123', false)
#10 [internal function]: Controller_Admin_Auth->action_index()
#11 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#12 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#14 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#15 {main}
2012-07-11 01:34:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: failsearch ~ APPPATH\views\admin\pages\V_pages.php [ 55 ]
2012-07-11 01:34:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: failsearch ~ APPPATH\views\admin\pages\V_pages.php [ 55 ]
--
#0 C:\wamp\www\frontend\application\views\admin\pages\V_pages.php(55): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 55, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\app.php(80): Kohana_Response->body(Object(View))
#6 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(40): Controller_App->action_search('page', 'pagename')
#7 [internal function]: Controller_Admin_Pages->action_search()
#8 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#9 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#12 {main}
2012-07-11 01:34:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: failsearch ~ APPPATH\views\admin\pages\V_pages.php [ 55 ]
2012-07-11 01:34:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: failsearch ~ APPPATH\views\admin\pages\V_pages.php [ 55 ]
--
#0 C:\wamp\www\frontend\application\views\admin\pages\V_pages.php(55): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 55, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\app.php(80): Kohana_Response->body(Object(View))
#6 C:\wamp\www\frontend\application\classes\controller\admin\pages.php(40): Controller_App->action_search('page', 'pagename')
#7 [internal function]: Controller_Admin_Pages->action_search()
#8 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Pages))
#9 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#12 {main}
2012-07-11 02:39:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
2012-07-11 02:39:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/img/ui-bg_glass_75_ffffff_1x400.png ~ SYSPATH\classes\kohana\request.php [ 1126 ]
--
#0 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#1 {main}
2012-07-11 02:47:13 --- ERROR: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\controller\admin\users.php [ 113 ]
2012-07-11 02:47:13 --- STRACE: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\controller\admin\users.php [ 113 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\users.php(113): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 113, Array)
#1 [internal function]: Controller_Admin_Users->action_edit()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-07-11 02:49:10 --- ERROR: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\controller\admin\users.php [ 113 ]
2012-07-11 02:49:10 --- STRACE: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\controller\admin\users.php [ 113 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\admin\users.php(113): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\wamp\www\fro...', 113, Array)
#1 [internal function]: Controller_Admin_Users->action_edit()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Users))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-07-11 03:02:29 --- ERROR: ErrorException [ 2 ]: mail() [function.mail]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
2012-07-11 03:02:29 --- STRACE: ErrorException [ 2 ]: mail() [function.mail]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() ~ MODPATH\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php [ 50 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mail() [<a href...', 'C:\wamp\www\fro...', 50, Array)
#1 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Transport\SimpleMailInvoker.php(50): mail('int3rhard@gmail...', 'dfgdg', '<p>???dfgd</p>?...', 'Message-ID: <13...', '')
#2 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Transport\MailTransport.php(183): Swift_Transport_SimpleMailInvoker->mail('int3rhard@gmail...', 'dfgdg', '<p>???dfgd</p>?...', 'Message-ID: <13...', '')
#3 C:\wamp\www\frontend\modules\email\vendor\swift\classes\Swift\Mailer.php(87): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#4 C:\wamp\www\frontend\modules\email\classes\email.php(142): Swift_Mailer->send(Object(Swift_Message))
#5 C:\wamp\www\frontend\application\classes\controller\admin\email.php(58): Email::send('int3rhard@gmail...', 'int3rhard@gmail...', 'dfgdg', '<p>??dfgd</p>?', true)
#6 [internal function]: Controller_Admin_Email->action_send()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Email))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}