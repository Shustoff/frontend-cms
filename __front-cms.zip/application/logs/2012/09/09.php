<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-09-09 15:56:52 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 15:56:52 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 15:57:46 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 15:57:46 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:00:39 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:00:39 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:22:09 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:22:09 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:22:18 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:22:18 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:23:25 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:23:25 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:23:49 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:23:49 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:23:58 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:23:58 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:24:24 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:24:24 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:24:27 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:24:27 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:25:52 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:25:52 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:25:58 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:25:58 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:26:01 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-09-09 16:26:01 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:26:18 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-09-09 16:26:18 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:26:28 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:26:28 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:27:16 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:27:16 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:27:40 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-09-09 16:27:40 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:28:11 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:28:11 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:28:55 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:28:55 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:29:11 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 16:29:11 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:30:26 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-09-09 16:30:26 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:30:38 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-09-09 16:30:38 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:30:41 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-09-09 16:30:41 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:30:42 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
2012-09-09 16:30:42 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-09 16:40:50 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-09-09 16:40:50 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1261): Kohana_ORM->check(NULL)
#1 C:\wamp\www\frontend\modules\orm\classes\model\auth\user.php(94): Kohana_ORM->update()
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\auth\orm.php(262): Model_Auth_User->complete_login()
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\auth\orm.php(107): Kohana_Auth_ORM->complete_login(Object(Model_User))
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(90): Kohana_Auth_ORM->_login('manager', 'admin123', false)
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth->login('manager', 'admin123', false)
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-09 16:42:15 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
2012-09-09 16:42:15 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH\orm\classes\kohana\orm.php [ 1174 ]
--
#0 C:\wamp\www\frontend\modules\orm\classes\kohana\orm.php(1261): Kohana_ORM->check(NULL)
#1 C:\wamp\www\frontend\modules\orm\classes\model\auth\user.php(94): Kohana_ORM->update()
#2 C:\wamp\www\frontend\modules\orm\classes\kohana\auth\orm.php(262): Model_Auth_User->complete_login()
#3 C:\wamp\www\frontend\modules\orm\classes\kohana\auth\orm.php(107): Kohana_Auth_ORM->complete_login(Object(Model_User))
#4 C:\wamp\www\frontend\modules\auth\classes\kohana\auth.php(90): Kohana_Auth_ORM->_login('man', 'admin123', false)
#5 C:\wamp\www\frontend\application\classes\controller\admin\auth.php(14): Kohana_Auth->login('man', 'admin123', false)
#6 [internal function]: Controller_Admin_Auth->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Admin_Auth))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-09-09 17:55:56 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
2012-09-09 17:55:56 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH\classes\controller\site\catalog.php [ 29 ]
--
#0 [internal function]: Controller_Site_Catalog->action_index()
#1 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Catalog))
#2 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#5 {main}