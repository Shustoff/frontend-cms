<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-05-16 08:15:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 08:15:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 08:16:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 08:16:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 08:16:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 08:16:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 08:16:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 08:16:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 08:17:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 08:17:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 08:17:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 08:17:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/jquery-ui-1.8.16.custom.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/jquery-ui-1.8.16.custom.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/jquery-ui-1.8.16.custom.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/jquery-ui-1.8.16.custom.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/jquery-ui-1.8.16.custom.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/jquery-ui-1.8.16.custom.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:25:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:25:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/jquery-ui-1.8.16.custom.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/jquery-ui-1.8.16.custom.css ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:26:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:26:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:34:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:34:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/less-1.3.0.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-1.7.2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/bootstrap.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery-ui-1.8.16.custom.min.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/modernizr-2.5.3.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/backbone.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/json2.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/underscore.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/user.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 20:06:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 20:06:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 20:06:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:06:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:06:24 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:06:24 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:07:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:07:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:07:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:07:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:08:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:08:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:08:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:08:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:10:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:10:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:10:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:10:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:10:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:10:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:10:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:10:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:10:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:10:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:13:55 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:13:55 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:16:01 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:16:01 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:17:08 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:17:08 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:17:08 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:17:08 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:17:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:17:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:17:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:17:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:17:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:17:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:17:16 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:17:16 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:17:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:17:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:17:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:17:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:17:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 20:17:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 20:18:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 20:18:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 20:18:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 20:18:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 20:18:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:18:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:18:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:18:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:18:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:18:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:18:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 20:18:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 20:18:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:18:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:18:20 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:18:20 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:18:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 20:18:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 20:18:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:18:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:18:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-05-16 20:18:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#1 {main}
2012-05-16 20:18:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:18:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:18:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:18:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:19:25 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:19:25 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:20:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:20:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:20:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:20:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:20:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:20:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:20:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:20:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:21:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:21:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:24:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:24:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:24:16 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:24:16 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:24:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:24:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:26:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:26:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:26:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:26:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:26:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:26:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:26:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:26:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:26:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:26:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:26:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:26:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:26:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:26:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:26:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:26:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:26:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:26:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:27:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:27:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:27:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:27:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:27:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:27:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:27:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:27:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:27:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:27:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:27:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:27:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:27:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:27:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:01 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:01 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL frontend was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:08 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:08 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL site was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL site was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:28:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:28:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:29:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:29:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:29:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:29:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:29:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:29:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:29:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:29:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:30:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:30:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:30:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:30:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:30:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:30:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:30:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:30:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:30:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:30:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}
2012-05-16 20:37:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/asd was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-05-16 20:37:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/asd was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Applications/MAMP/htdocs/frontend/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Applications/MAMP/htdocs/frontend/index.php(109): Kohana_Request->execute()
#3 {main}