<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-08-15 10:13:27 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:13:27 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:13:32 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:13:32 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:49:21 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:49:21 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:49:21 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:49:21 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:49:21 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:49:21 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:49:22 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:49:22 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:49:38 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:49:38 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:49:38 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:49:38 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:49:39 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:49:39 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:49:39 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:49:39 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:50:34 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:50:34 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 10:50:35 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 10:50:35 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:01:57 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 11:01:57 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:02:17 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
2012-08-15 11:02:17 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH\classes\controller\site\page.php [ 87 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\page.php(87): Kohana_Core::error_handler(2048, 'Creating defaul...', 'C:\wamp\www\fro...', 87, Array)
#1 [internal function]: Controller_Site_Page->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:18:51 --- ERROR: ErrorException [ 8 ]: Undefined variable: debug ~ APPPATH\views\site\index.php [ 49 ]
2012-08-15 11:18:51 --- STRACE: ErrorException [ 8 ]: Undefined variable: debug ~ APPPATH\views\site\index.php [ 49 ]
--
#0 C:\wamp\www\frontend\application\views\site\index.php(49): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 49, Array)
#1 C:\wamp\www\frontend\system\classes\kohana\view.php(61): include('C:\wamp\www\fro...')
#2 C:\wamp\www\frontend\system\classes\kohana\view.php(343): Kohana_View::capture('C:\wamp\www\fro...', Array)
#3 C:\wamp\www\frontend\system\classes\kohana\view.php(228): Kohana_View->render()
#4 C:\wamp\www\frontend\system\classes\kohana\response.php(160): Kohana_View->__toString()
#5 C:\wamp\www\frontend\application\classes\controller\site\home.php(57): Kohana_Response->body(Object(View))
#6 [internal function]: Controller_Site_Home->action_index()
#7 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#8 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#11 {main}
2012-08-15 11:40:24 --- ERROR: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
2012-08-15 11:40:24 --- STRACE: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(7): Kohana_ORM->find('cache')
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:40:44 --- ERROR: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
2012-08-15 11:40:44 --- STRACE: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(7): Kohana_ORM->find_all('cache')
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:40:45 --- ERROR: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
2012-08-15 11:40:45 --- STRACE: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(7): Kohana_ORM->find_all('cache')
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:41:05 --- ERROR: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
2012-08-15 11:41:05 --- STRACE: Kohana_Exception [ 0 ]: Method find() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 885 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(7): Kohana_ORM->find()
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:41:14 --- ERROR: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
2012-08-15 11:41:14 --- STRACE: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(7): Kohana_ORM->find_all('cache')
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:41:22 --- ERROR: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
2012-08-15 11:41:22 --- STRACE: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(7): Kohana_ORM->find_all()
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:41:23 --- ERROR: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
2012-08-15 11:41:23 --- STRACE: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(7): Kohana_ORM->find_all()
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:41:26 --- ERROR: ErrorException [ 8 ]: Object of class Database_MySQL_Result could not be converted to int ~ APPPATH\classes\controller\site\main.php [ 8 ]
2012-08-15 11:41:26 --- STRACE: ErrorException [ 8 ]: Object of class Database_MySQL_Result could not be converted to int ~ APPPATH\classes\controller\site\main.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(8): Kohana_Core::error_handler(8, 'Object of class...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:41:55 --- ERROR: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
2012-08-15 11:41:55 --- STRACE: Kohana_Exception [ 0 ]: Method find_all() cannot be called on loaded objects ~ MODPATH\orm\classes\kohana\orm.php [ 909 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(7): Kohana_ORM->find_all()
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:42:23 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\classes\controller\site\main.php [ 9 ]
2012-08-15 11:42:23 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\classes\controller\site\main.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-15 11:42:27 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\main.php [ 9 ]
2012-08-15 11:42:27 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\main.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-15 11:42:39 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\main.php [ 9 ]
2012-08-15 11:42:39 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Option as array ~ APPPATH\classes\controller\site\main.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-08-15 11:42:56 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$cache ~ APPPATH\classes\controller\site\main.php [ 9 ]
2012-08-15 11:42:56 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$cache ~ APPPATH\classes\controller\site\main.php [ 9 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(9): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 9, Array)
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:43:15 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$cache ~ APPPATH\classes\controller\site\main.php [ 8 ]
2012-08-15 11:43:15 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$cache ~ APPPATH\classes\controller\site\main.php [ 8 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\main.php(8): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\wamp\www\fro...', 8, Array)
#1 [internal function]: Controller_Site_Main->before()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(103): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:54:30 --- ERROR: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH\classes\controller\site\home.php [ 23 ]
2012-08-15 11:54:30 --- STRACE: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH\classes\controller\site\home.php [ 23 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(23): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 23, Array)
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:54:35 --- ERROR: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH\classes\controller\site\home.php [ 23 ]
2012-08-15 11:54:35 --- STRACE: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH\classes\controller\site\home.php [ 23 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(23): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\wamp\www\fro...', 23, Array)
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}
2012-08-15 11:54:56 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 11:54:56 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(23): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 11:56:01 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 11:56:01 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(23): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 11:57:55 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 11:57:55 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(23): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 11:58:32 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 11:58:32 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(23): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 11:58:53 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 11:58:53 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(23): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:03:16 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:03:16 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(23): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:05:12 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:05:12 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(25): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:05:44 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:05:44 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(25): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:07:59 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:07:59 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(26): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:11:13 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:11:13 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(26): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:13:59 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:13:59 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(30): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:14:37 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:14:37 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(30): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:16:55 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:16:55 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(26): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:17:18 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:17:18 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(26): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:20:01 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:20:01 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(26): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:22:52 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:22:52 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(26): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:24:29 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:24:29 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(26): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:30:15 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:30:15 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(26): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:30:50 --- ERROR: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
2012-08-15 12:30:50 --- STRACE: ErrorException [ 2 ]: mysql_fetch_object(): supplied argument is not a valid MySQL result resource ~ MODPATH\database\classes\kohana\database\mysql\result.php [ 62 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'mysql_fetch_obj...', 'C:\wamp\www\fro...', 62, Array)
#1 C:\wamp\www\frontend\modules\database\classes\kohana\database\mysql\result.php(62): mysql_fetch_object(0, 'Model_Page', NULL)
#2 C:\wamp\www\frontend\application\classes\controller\site\home.php(28): Kohana_Database_MySQL_Result->current()
#3 [internal function]: Controller_Site_Home->action_index()
#4 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#5 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#8 {main}
2012-08-15 12:32:02 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\classes\controller\site\home.php [ 26 ]
2012-08-15 12:32:02 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH\classes\controller\site\home.php [ 26 ]
--
#0 C:\wamp\www\frontend\application\classes\controller\site\home.php(26): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\wamp\www\fro...', 26, Array)
#1 [internal function]: Controller_Site_Home->action_index()
#2 C:\wamp\www\frontend\system\classes\kohana\request\client\internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Home))
#3 C:\wamp\www\frontend\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 C:\wamp\www\frontend\system\classes\kohana\request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 C:\wamp\www\frontend\index.php(109): Kohana_Request->execute()
#6 {main}