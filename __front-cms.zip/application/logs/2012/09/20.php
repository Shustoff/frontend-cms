<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-09-20 15:47:23 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-20 15:47:23 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}
2012-09-20 15:56:17 --- ERROR: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
2012-09-20 15:56:17 --- STRACE: Kohana_HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/site/page.php [ 31 ]
--
#0 [internal function]: Controller_Site_Page->action_index()
#1 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Site_Page))
#2 /home/shustoff/music.shustoff.su/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/shustoff/music.shustoff.su/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/shustoff/music.shustoff.su/index.php(109): Kohana_Request->execute()
#5 {main}