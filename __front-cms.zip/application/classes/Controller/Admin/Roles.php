<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Admin_Roles extends Controller_Admin_App {

    public function before()
    {
        parent::before();
        $roles = Auth::instance()->get_user()->roles->find_all();
        foreach ($roles as $role)
        {
            if ($role->name === 'login')
                $permission = FALSE;
            else
                $role->users == 0 ? $permission = FALSE : $permission = TRUE;
        }
        if ( ! $permission) die('Вам запрещен доступ к этой странице');
    }

    public function action_index()
    {
        parent::action_main($model = 'Role');
    }

    public function action_on($table = 'roles')
    {
        parent::action_on($table);
    }

    public function action_off($table = 'roles')
    {
        parent::action_off($table);
    }

    public function action_intrash($model = 'Role')
    {
        parent::action_intrash($model);
    }

    public function action_addroles()
    {
        $view = View::factory('admin/roles/V_addrole');
        $this->response->body($view);
    }

    public function action_add($model = 'Role')
    {
        try
        {
            $unique_role  = ORM::factory('Role')->unique('name', $_POST['name']);
            if ($unique_role) {
                $added = ORM::factory($model)->values($_POST)->save();
                echo $added->id;
            } else {
                echo 'Это название роли уже существует.';
            }
        }
        catch (ORM_Validation_Exception $e)
        {
            $errors = $e->errors('validation');
            foreach ($errors as $error)
            {
                echo $error . '<br>';
            }
        }
    }

    // Проверяем название роли на уникальность
    public function action_checkrole()
    {
        $unique_role  = ORM::factory('Role')->unique('name', $_POST['name']);
        if ( ! $unique_role) echo 'Это название уже используется';
    }

    public function action_editroles()
    {
        $id = $this->request->param('id');
        $role = ORM::factory('Role', $id);

        $view = View::factory('admin/roles/V_editrole')
                ->set('role', $role);
        $this->response->body($view);

    }

    public function action_edit($model = 'Role')
    {
        parent::action_edit($model);
    }

}